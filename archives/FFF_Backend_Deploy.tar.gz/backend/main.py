import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import select

from core.db import init_db, get_session
from core.auth import get_password_hash
from models import Artwork, VisibilityStatus, User
from api.routers import api_router

app = FastAPI(
    title="FFF Master API",
    description="Backend API for Freelance Illustrator Platform",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all for development flexibility
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    init_db()
    # Ensure upload directories exist
    os.makedirs("uploads/slips", exist_ok=True)
    os.makedirs("uploads/originals", exist_ok=True)
    os.makedirs("uploads/watermarked", exist_ok=True)
    os.makedirs("uploads/portfolio", exist_ok=True)
    # Seed mock portfolio data if empty
    with next(get_session()) as session:
        existing = session.exec(select(Artwork)).first()
        if not existing:
            mock_artworks = [
                Artwork(title="Cyberpunk Cityscape", description="Personal project.", image_url="https://images.unsplash.com/photo-1605806616949-1e87b487cb2a?q=80&w=2000&auto=format&fit=crop", visibility_status=VisibilityStatus.PUBLIC),
                Artwork(title="Character Concept A", description="Fantasy character design.", image_url="https://images.unsplash.com/photo-1544830154-1b32d207ec17?q=80&w=1400&auto=format&fit=crop", visibility_status=VisibilityStatus.PUBLIC),
                Artwork(title="Secret Client Work", description="Should not be visible publicly.", image_url="https://images.unsplash.com/photo-1620121692029-d088224ddc74?q=80&w=1400&auto=format&fit=crop", visibility_status=VisibilityStatus.PRIVATE),
                Artwork(title="Mech Design", description="Mecha study.", image_url="https://images.unsplash.com/photo-1593305841991-05c297ba4575?q=80&w=1200&auto=format&fit=crop", visibility_status=VisibilityStatus.PUBLIC),
                Artwork(title="Fantasy Landscape", description="Environment concept art.", image_url="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1600&auto=format&fit=crop", visibility_status=VisibilityStatus.PUBLIC),
                Artwork(title="Bust Up Commission", description="Commission for a VTuber.", image_url="https://images.unsplash.com/photo-1563089145-599997674d42?q=80&w=1400&auto=format&fit=crop", visibility_status=VisibilityStatus.PUBLIC),
            ]
            session.add_all(mock_artworks)
            session.commit()

        # Seed mock testing accounts if not present
        existing_admin = session.exec(select(User).where(User.email == "admin@example.com")).first()
        if not existing_admin:
            admin_user = User(
                email="admin@example.com",
                full_name="Main Artist",
                hashed_password=get_password_hash("password123"),
                is_admin=True
            )
            session.add(admin_user)
            
        existing_client = session.exec(select(User).where(User.email == "client@example.com")).first()
        if not existing_client:
            client_user = User(
                email="client@example.com",
                full_name="Valued Client",
                hashed_password=get_password_hash("password123"),
                is_admin=False
            )
            session.add(client_user)
            
        session.commit()

from fastapi import WebSocket, WebSocketDisconnect, Query
from core.websocket import manager
from core.auth import decode_access_token

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket, token: str = Query(...)):
    payload = decode_access_token(token)
    if not payload:
        await websocket.close(code=4003)
        return
        
    email = payload.get("sub")
    if not email:
        await websocket.close(code=4003)
        return
        
    from core.db import engine
    from sqlmodel import Session
    with Session(engine) as session:
        user = session.exec(select(User).where(User.email == email)).first()
        if not user:
            await websocket.close(code=4003)
            return
        user_id = user.id
        
    await manager.connect(user_id, websocket)
    try:
        while True:
            # Keep connection open and receive messages if any
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(user_id, websocket)
    except Exception:
        manager.disconnect(user_id, websocket)

@app.get("/")
def read_root():
    return {"message": "Welcome to FFF Master API"}

app.include_router(api_router)

