import sqlite3

def upgrade_db():
    conn = sqlite3.connect('test.db')
    cursor = conn.cursor()
    try:
        cursor.execute("ALTER TABLE artwork ADD COLUMN work_type VARCHAR DEFAULT 'ILLUSTRATION'")
        print("Added work_type")
    except Exception as e:
        print("work_type error:", e)
        
    try:
        cursor.execute("ALTER TABLE artwork ADD COLUMN character_id INTEGER REFERENCES character(id)")
        print("Added character_id")
    except Exception as e:
        print("character_id error:", e)

    conn.commit()
    conn.close()

if __name__ == '__main__':
    upgrade_db()
