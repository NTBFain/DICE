from pydantic import BaseModel
from typing import Optional

class CharacterResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    theme_color: Optional[str] = None
    image_url: Optional[str] = None
