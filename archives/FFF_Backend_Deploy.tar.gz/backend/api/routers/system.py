from fastapi import APIRouter, Depends, HTTPException, UploadFile, Form, File as FormFile
from fastapi.responses import FileResponse as SecureFileResponse
from sqlmodel import Session
import os
import secrets
import shutil

from core.db import get_session
from core.auth import get_admin_user
from models import User
from schemas import CommissionStatusResponse, CommissionStatusUpdateRequest
from services import get_setting, set_setting

router = APIRouter(prefix="/api/commissions", tags=["commissions"])

@router.get("/status", response_model=CommissionStatusResponse)
def get_commission_status(session: Session = Depends(get_session)):
    is_open_str = get_setting(session, "commissions_open", "false")
    return CommissionStatusResponse(open=(is_open_str == "true"))

@router.post("/status", response_model=CommissionStatusResponse)
def update_commission_status(request: CommissionStatusUpdateRequest, session: Session = Depends(get_session), admin_user: User = Depends(get_admin_user)):
    val_str = "true" if request.open else "false"
    set_setting(session, "commissions_open", val_str)
    return CommissionStatusResponse(open=request.open)

@router.get("/watermark")
def get_watermark_settings(session: Session = Depends(get_session)):
    w_type = get_setting(session, "watermark_type", "text")
    w_text = get_setting(session, "watermark_text", "WIP SOM JEED")
    w_image_path = get_setting(session, "watermark_image_path", "")
    w_opacity = get_setting(session, "watermark_opacity", "0.25")
    return {
        "type": w_type,
        "text": w_text,
        "image_path": w_image_path,
        "opacity": float(w_opacity)
    }

@router.post("/watermark")
def update_watermark_settings(
    type: str = Form(...),
    text: str = Form(""),
    opacity: float = Form(0.25),
    image: UploadFile = FormFile(None),
    session: Session = Depends(get_session),
    admin_user: User = Depends(get_admin_user)
):
    set_setting(session, "watermark_type", type)
    set_setting(session, "watermark_text", text)
    set_setting(session, "watermark_opacity", str(opacity))
    
    if image:
        os.makedirs("uploads/watermark_logos", exist_ok=True)
        ext = os.path.splitext(image.filename)[1]
        filename = f"logo_{secrets.token_hex(4)}{ext}"
        logo_path = os.path.join("uploads/watermark_logos", filename)
        
        with open(logo_path, "wb") as buffer:
            shutil.copyfileobj(image.file, buffer)
            
        web_path = f"/api/commissions/watermark/logo?filename={filename}"
        set_setting(session, "watermark_image_path", web_path)
        set_setting(session, "watermark_image_filename", filename)
        
    return {
        "type": type,
        "text": text,
        "image_path": get_setting(session, "watermark_image_path", ""),
        "opacity": opacity
    }

@router.get("/watermark/logo")
def get_watermark_logo(filename: str):
    filename = os.path.basename(filename)
    logo_path = os.path.join("uploads/watermark_logos", filename)
    if os.path.exists(logo_path):
        return SecureFileResponse(logo_path)
    raise HTTPException(status_code=404, detail="Watermark logo not found")

