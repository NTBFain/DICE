from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    PROJECT_NAME: str = "FFF Backend"
    DATABASE_URL: str = "sqlite:///./test.db"  # Fallback to local SQLite for Phase 1 dev
    REDIS_URL: str = "redis://localhost:6379/0"
    SECRET_KEY: str = "super_secret_key_change_me_in_production_123456"
    
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
