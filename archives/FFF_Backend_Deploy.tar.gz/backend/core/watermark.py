import os
from PIL import Image, ImageDraw, ImageFont

def apply_watermark(
    input_image_path: str,
    output_image_path: str,
    text: str = "WIP SOM JEED",
    watermark_type: str = "text",
    logo_filename: str = "",
    opacity: float = 0.25
) -> bool:
    try:
        with Image.open(input_image_path) as im:
            if im.mode != 'RGBA':
                im = im.convert('RGBA')
            
            width, height = im.size
            watermark_layer = Image.new('RGBA', im.size, (0, 0, 0, 0))
            
            logo_applied = False
            if watermark_type == "image" and logo_filename:
                logo_path = os.path.join("uploads/watermark_logos", logo_filename)
                if os.path.exists(logo_path):
                    with Image.open(logo_path) as logo:
                        if logo.mode != 'RGBA':
                            logo = logo.convert('RGBA')
                        
                        logo_w, logo_h = logo.size
                        # Scale logo to be roughly 15% of the original image width
                        target_w = int(width * 0.15)
                        if target_w < 50:
                            target_w = 50
                        target_h = int(logo_h * (target_w / logo_w))
                        if target_h < 10:
                            target_h = 10
                            
                        logo_resized = logo.resize((target_w, target_h), Image.Resampling.LANCZOS)
                        
                        # Apply custom opacity to the logo's alpha channel
                        r, g, b, a = logo_resized.split()
                        mask_a = a  # Keep original alpha mask for pasting
                        a = a.point(lambda p: int(p * opacity))
                        logo_resized = Image.merge('RGBA', (r, g, b, a))
                        
                        # Paste logo in a grid tiling pattern
                        step_x = max(200, int(target_w * 2.5))
                        step_y = max(150, int(target_h * 2.5))
                        for x in range(0, width, step_x):
                            for y in range(0, height, step_y):
                                watermark_layer.paste(logo_resized, (x + 20, y + 20), mask_a)
                        logo_applied = True
            
            # Fallback or Text Watermark
            if not logo_applied or watermark_type == "text":
                draw = ImageDraw.Draw(watermark_layer)
                font_size = int(width / 25)
                if font_size < 12:
                    font_size = 12
                    
                try:
                    font_path = "C:\\Windows\\Fonts\\arial.ttf"
                    if not os.path.exists(font_path):
                        font_path = "arial.ttf"
                    font = ImageFont.truetype(font_path, font_size)
                except Exception:
                    font = ImageFont.load_default()
                    
                step_x = max(400, int(width / 2))
                step_y = max(300, int(height / 4))
                
                alpha_val = int(opacity * 255)
                stroke_alpha = int(opacity * 255 * 0.6)
                
                for x in range(0, width, step_x):
                    for y in range(0, height, step_y):
                        draw.text(
                            (x + 20, y + 20), 
                            text, 
                            fill=(255, 255, 255, alpha_val), 
                            font=font, 
                            stroke_width=1, 
                            stroke_fill=(0, 0, 0, stroke_alpha)
                        )
                        
            watermarked_im = Image.alpha_composite(im, watermark_layer)
            
            _, ext = os.path.splitext(output_image_path.lower())
            if ext in ['.jpg', '.jpeg']:
                watermarked_im = watermarked_im.convert('RGB')
                watermarked_im.save(output_image_path, 'JPEG', quality=85)
            else:
                watermarked_im.save(output_image_path, 'PNG')
            return True
    except Exception as e:
        print(f"Error applying watermark: {e}")
        try:
            with Image.open(input_image_path) as im:
                im.save(output_image_path)
            return True
        except Exception:
            return False

