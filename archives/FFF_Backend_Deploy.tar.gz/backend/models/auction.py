from typing import Optional, List
from sqlmodel import Field, SQLModel, Relationship
from datetime import datetime
from .base import AuctionType, AuctionStatus

class AuctionBase(SQLModel):
    title: str
    description: str
    image_url: Optional[str] = None
    auction_type: AuctionType = Field(default=AuctionType.ADOPTABLE)
    status: AuctionStatus = Field(default=AuctionStatus.ACTIVE)
    starting_bid: float
    bid_increment: float
    auto_buy: Optional[float] = None
    start_time: datetime
    end_time: datetime
    winning_bid: Optional[float] = None

class Auction(AuctionBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    winner_id: Optional[int] = Field(default=None, foreign_key="user.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    bids: List["Bid"] = Relationship(back_populates="auction")
    winner: Optional["User"] = Relationship(sa_relationship_kwargs={"primaryjoin": "Auction.winner_id==User.id"})

class BidBase(SQLModel):
    amount: float

class Bid(BidBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    auction_id: int = Field(foreign_key="auction.id")
    bidder_id: int = Field(foreign_key="user.id")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    auction: Auction = Relationship(back_populates="bids")
    bidder: "User" = Relationship()
