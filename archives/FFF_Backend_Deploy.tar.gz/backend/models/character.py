from typing import Optional
from sqlmodel import Field, SQLModel
from datetime import datetime

class CharacterBase(SQLModel):
    name: str
    description: Optional[str] = None
    theme_color: Optional[str] = None
    image_url: Optional[str] = None

class Character(CharacterBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
