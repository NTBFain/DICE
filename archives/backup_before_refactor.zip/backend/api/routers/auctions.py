from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from typing import List
from datetime import datetime, timezone

from core.db import get_session
from core.auth import get_current_user, get_admin_user
from models import Auction, AuctionStatus, AuctionType, Bid, User, Notification, NotificationType
from schemas import AuctionCreateRequest, AuctionResponse, BidCreateRequest
from services.auction_service import check_and_close_auction, get_bid_responses

def _build_auction_response(a: Auction, bid_res: List, session: Session) -> AuctionResponse:
    winner_name = None
    if a.winner_id:
        winner = session.get(User, a.winner_id)
        if winner:
            winner_name = winner.full_name
    return AuctionResponse(
        id=a.id,
        title=a.title,
        description=a.description,
        image_url=a.image_url,
        auction_type=a.auction_type.value,
        status=a.status.value,
        starting_bid=a.starting_bid,
        bid_increment=a.bid_increment,
        auto_buy=a.auto_buy,
        start_time=a.start_time.replace(tzinfo=timezone.utc),
        end_time=a.end_time.replace(tzinfo=timezone.utc),
        winner_id=a.winner_id,
        winner_name=winner_name,
        winning_bid=a.winning_bid,
        created_at=a.created_at.replace(tzinfo=timezone.utc),
        bids=bid_res
    )

router = APIRouter(prefix="/api/auctions", tags=["auctions"])

@router.post("", response_model=AuctionResponse)
def api_create_auction(request: AuctionCreateRequest, session: Session = Depends(get_session), admin_user: User = Depends(get_admin_user)):
    auction = Auction(
        title=request.title,
        description=request.description,
        image_url=request.image_url,
        auction_type=AuctionType(request.auction_type),
        status=AuctionStatus.ACTIVE,
        starting_bid=request.starting_bid,
        bid_increment=request.bid_increment,
        auto_buy=request.auto_buy,
        start_time=request.start_time,
        end_time=request.end_time
    )
    session.add(auction)
    session.commit()
    session.refresh(auction)
    return auction

@router.get("", response_model=List[AuctionResponse])
async def api_get_auctions(session: Session = Depends(get_session)):
    auctions = session.exec(select(Auction)).all()
    
    # Check closing for each
    for a in auctions:
        await check_and_close_auction(a, session)
        
    responses = []
    for a in auctions:
        sorted_bids = session.exec(
            select(Bid).where(Bid.auction_id == a.id).order_by(Bid.amount.desc())
        ).all()
        bid_res = get_bid_responses(sorted_bids, session)
        
        responses.append(_build_auction_response(a, bid_res, session))
    return responses

@router.get("/{auction_id}", response_model=AuctionResponse)
async def api_get_auction_by_id(auction_id: int, session: Session = Depends(get_session)):
    auction = session.get(Auction, auction_id)
    if not auction:
        raise HTTPException(status_code=404, detail="Auction not found")
        
    await check_and_close_auction(auction, session)
    
    sorted_bids = session.exec(
        select(Bid).where(Bid.auction_id == auction.id).order_by(Bid.amount.desc())
    ).all()
    bid_res = get_bid_responses(sorted_bids, session)
    
    return _build_auction_response(auction, bid_res, session)

@router.post("/{auction_id}/bid", response_model=AuctionResponse)
async def api_place_bid(auction_id: int, request: BidCreateRequest, session: Session = Depends(get_session), current_user: User = Depends(get_current_user)):
    auction = session.get(Auction, auction_id)
    if not auction:
        raise HTTPException(status_code=404, detail="Auction not found")
        
    await check_and_close_auction(auction, session)
    
    if auction.status != AuctionStatus.ACTIVE:
        raise HTTPException(status_code=400, detail="Auction has ended or is cancelled")
        
    now = datetime.utcnow()
    if now < auction.start_time or now > auction.end_time:
        raise HTTPException(status_code=400, detail="Auction is outside bidding time")
        
    highest_bid = session.exec(
        select(Bid).where(Bid.auction_id == auction_id).order_by(Bid.amount.desc())
    ).first()
    previous_highest = highest_bid
    
    min_required_bid = auction.starting_bid
    if highest_bid:
        min_required_bid = highest_bid.amount + auction.bid_increment
        
    if request.amount < min_required_bid:
        raise HTTPException(status_code=400, detail=f"Bid amount must be at least ${min_required_bid}")
        
    new_bid = Bid(
        auction_id=auction_id,
        bidder_id=current_user.id,
        amount=request.amount
    )
    session.add(new_bid)
    session.commit()
    session.refresh(new_bid)
    
    # Sniper Protection (Anti-Sniping)
    time_left_seconds = (auction.end_time - now).total_seconds()
    if 0 < time_left_seconds <= 300:
        from datetime import timedelta
        auction.end_time = auction.end_time + timedelta(minutes=5)
        session.add(auction)
        session.commit()
        session.refresh(auction)
        
    # Notify previous highest bidder
    if previous_highest and previous_highest.bidder_id != current_user.id:
        from services.notification_service import create_notification
        await create_notification(
            session=session,
            user_id=previous_highest.bidder_id,
            title="Outbid Alert!",
            message=f"You have been outbid on auction '{auction.title}' by ฿{request.amount}.",
            link=f"/auctions/{auction.id}",
            type=NotificationType.AUCTION
        )
    
    # Check Auto Buy
    if auction.auto_buy is not None and request.amount >= auction.auto_buy:
        auction.status = AuctionStatus.ENDED
        auction.winner_id = current_user.id
        auction.winning_bid = request.amount
        session.add(auction)
        session.commit()
        
        await check_and_close_auction(auction, session)
        
    # Refresh to get updated bids
    session.refresh(auction)
    
    sorted_bids = session.exec(
        select(Bid).where(Bid.auction_id == auction.id).order_by(Bid.amount.desc())
    ).all()
    bid_res = get_bid_responses(sorted_bids, session)
    
    response_data = _build_auction_response(auction, bid_res, session)
    
    # Broadcast updated auction to WebSocket
    from fastapi.encoders import jsonable_encoder
    from core.websocket import manager
    await manager.broadcast({
        "type": "auction_updated",
        "data": jsonable_encoder(response_data)
    })
    
    return response_data

@router.post("/{auction_id}/close", response_model=AuctionResponse)
async def api_close_auction_manually(auction_id: int, session: Session = Depends(get_session), admin_user: User = Depends(get_admin_user)):
    auction = session.get(Auction, auction_id)
    if not auction:
        raise HTTPException(status_code=404, detail="Auction not found")
        
    if auction.status != AuctionStatus.ACTIVE:
        raise HTTPException(status_code=400, detail="Auction is already closed")
        
    auction.end_time = datetime.utcnow()
    session.add(auction)
    session.commit()
    session.refresh(auction)
    
    await check_and_close_auction(auction, session)
    
    sorted_bids = session.exec(
        select(Bid).where(Bid.auction_id == auction.id).order_by(Bid.amount.desc())
    ).all()
    bid_res = get_bid_responses(sorted_bids, session)
    
    return _build_auction_response(auction, bid_res, session)
