'use client';

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getOrders,
  createOrder,
  getInvoices,
  payInvoice,
  getRevisions,
  requestRevision,
  getFiles,
  downloadOrderFile,
  getCommissionStatus,
  Order,
  MilestoneInvoice,
  Revision,
  OrderFile,
} from '@/lib/api';
import { useAuth } from '@/components/AuthContext';
import { useRouter } from '@/i18n/routing';
import { useTranslations } from 'next-intl';
import {
  Plus,
  Loader2,
  Calendar,
  DollarSign,
  Layers,
  ArrowRight,
  FileCheck,
  Upload,
  CheckCircle,
  HelpCircle,
  FileText,
  AlertCircle,
  ArrowDownToLine,
  Lock,
  RefreshCw,
} from 'lucide-react';
import SecureImage from '@/components/SecureImage';
import ChatBox from '@/components/ChatBox';

export default function ClientDashboard() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const t = useTranslations('ClientDashboard');
  const queryClient = useQueryClient();
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);

  // Modal / Form States
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const [revisionFeedback, setRevisionFeedback] = useState('');
  const [uploadingSlipId, setUploadingSlipId] = useState<number | null>(null);

  // Redirect if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [authLoading, user, router]);

  // Queries
  const { data: commissionStatus = { open: false }, isLoading: loadingStatus } = useQuery({
    queryKey: ['commission-status'],
    queryFn: getCommissionStatus,
  });

  const { data: orders = [], isLoading: loadingOrders, refetch: refetchOrders } = useQuery({
    queryKey: ['client-orders'],
    queryFn: getOrders,
    enabled: !!user,
  });

  const selectedOrder = orders.find((o) => o.id === selectedOrderId);

  const { data: invoices = [], isLoading: loadingInvoices } = useQuery({
    queryKey: ['order-invoices', selectedOrderId],
    queryFn: () => getInvoices(selectedOrderId!),
    enabled: !!selectedOrderId,
  });

  const { data: revisions = [], isLoading: loadingRevisions } = useQuery({
    queryKey: ['order-revisions', selectedOrderId],
    queryFn: () => getRevisions(selectedOrderId!),
    enabled: !!selectedOrderId,
  });

  const { data: files = [], isLoading: loadingFiles } = useQuery({
    queryKey: ['order-files', selectedOrderId],
    queryFn: () => getFiles(selectedOrderId!),
    enabled: !!selectedOrderId,
  });

  // Mutations
  const createOrderMutation = useMutation({
    mutationFn: createOrder,
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['client-orders'] });
      setShowCreateModal(false);
      setNewTitle('');
      setNewDesc('');
      setSelectedOrderId(data.id);
    },
  });

  const submitRevisionMutation = useMutation({
    mutationFn: (feedback: string) => requestRevision(selectedOrderId!, feedback),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['order-revisions', selectedOrderId] });
      setRevisionFeedback('');
    },
  });

  const uploadSlipMutation = useMutation({
    mutationFn: ({ invoiceId, file }: { invoiceId: number; file: File }) =>
      payInvoice(invoiceId, file),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['order-invoices', selectedOrderId] });
      setUploadingSlipId(null);
    },
  });

  if (authLoading || !user) {
    return (
      <div className="flex-1 flex items-center justify-center p-20">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    createOrderMutation.mutate({ title: newTitle, description: newDesc });
  };

  const handleUploadSlip = (invoiceId: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadingSlipId(invoiceId);
      uploadSlipMutation.mutate({ invoiceId, file });
    }
  };

  const handleDownload = async (file: OrderFile) => {
    try {
      await downloadOrderFile(selectedOrderId!, file.id, file.filename);
    } catch (err) {
      alert('Could not download file. Please ensure invoices are fully paid for final files.');
    }
  };

  const getStatusBadgeClass = (status: Order['status']) => {
    switch (status) {
      case 'PENDING':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'ACCEPTED':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'SKETCHING':
        return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'COLORING':
        return 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20';
      case 'COMPLETED':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'CANCELLED':
        return 'bg-red-500/10 text-red-400 border-red-500/20';
    }
  };

  const steps = ['PENDING', 'ACCEPTED', 'SKETCHING', 'COLORING', 'COMPLETED'];
  const getStepIndex = (status: string) => steps.indexOf(status);

  return (
    <div className="flex-1 flex flex-col lg:flex-row h-[calc(100vh-4rem)] overflow-hidden">
      {/* Left Panel: Orders list */}
      <div className="w-full lg:w-96 border-r border-neutral-200 dark:border-neutral-800 bg-neutral-100 dark:bg-neutral-900/20 flex flex-col overflow-y-auto">
        <div className="p-6 border-b border-neutral-200 dark:border-neutral-800 flex justify-between items-center sticky top-0 bg-white dark:bg-neutral-950 z-10">
          <h2 className="text-xl font-bold text-neutral-900 dark:text-white flex items-center gap-2">
            {t('myCommissions')}
            <button
              onClick={() => refetchOrders()}
              className="text-neutral-500 dark:text-neutral-500 hover:text-neutral-900 dark:text-white transition-colors cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </h2>
          <button
            onClick={() => {
              if (commissionStatus.open) {
                setShowCreateModal(true);
              }
            }}
            disabled={!commissionStatus.open || loadingStatus}
            className={`flex items-center gap-1 text-xs font-bold px-3 py-2 rounded-xl transition-all shadow-lg ${
              commissionStatus.open
                ? 'bg-blue-600 hover:bg-blue-500 text-white cursor-pointer hover:scale-[1.02] shadow-blue-600/10'
                : 'bg-neutral-200 dark:bg-neutral-800 text-neutral-500 dark:text-neutral-500 border border-neutral-700/60 cursor-not-allowed shadow-none'
            }`}
          >
            {loadingStatus ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Plus className="w-4 h-4" />
            )}
            {commissionStatus.open ? t('newRequest') : t('closed')}
          </button>
        </div>

        {!loadingStatus && !commissionStatus.open && (
          <div className="mx-4 mt-4 p-3.5 bg-red-500/5 border border-red-500/10 rounded-2xl flex items-start gap-2.5 shadow-[0_0_12px_rgba(239,68,68,0.02)] shrink-0">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-bold text-red-400">{t('commissionsClosed')}</h4>
              <p className="text-[10px] text-neutral-600 dark:text-neutral-400 mt-0.5 leading-relaxed">{t('notAccepting')}</p>
            </div>
          </div>
        )}

        <div className="flex-1 p-4 space-y-3">
          {loadingOrders ? (
            <div className="flex justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
            </div>
          ) : orders.length === 0 ? (
            <div className="text-center py-20 bg-neutral-50 dark:bg-neutral-900/30 border border-neutral-800/50 rounded-2xl p-6">
              <HelpCircle className="w-12 h-12 text-neutral-700 mx-auto mb-3" />
              <h3 className="font-semibold text-neutral-600 dark:text-neutral-400">{t('noRequests')}</h3>
              <p className="text-xs text-neutral-600 mt-1">{t('submitFirst')}</p>
            </div>
          ) : (
            orders.map((order) => (
              <button
                key={order.id}
                onClick={() => setSelectedOrderId(order.id)}
                className={`w-full text-left p-4 rounded-2xl border transition-all cursor-pointer flex flex-col gap-2 ${
                  selectedOrderId === order.id
                    ? 'bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 shadow-md shadow-black/40'
                    : 'bg-neutral-50 dark:bg-neutral-900/40 border-neutral-800/80 hover:bg-neutral-100 dark:bg-neutral-900/60 hover:border-neutral-200 dark:border-neutral-800'
                }`}
              >
                <div className="flex justify-between items-start gap-2">
                  <h3 className="font-semibold text-neutral-900 dark:text-white truncate text-sm">{order.title}</h3>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getStatusBadgeClass(order.status)}`}>
                    {order.status}
                  </span>
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-400 line-clamp-1">{order.description}</p>
                <div className="flex items-center justify-between text-[10px] text-neutral-500 dark:text-neutral-500 mt-1 pt-2 border-t border-neutral-800/50">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> {new Date(order.created_at).toLocaleDateString()}
                  </span>
                  {order.agreed_price ? (
                    <span className="text-blue-400 font-semibold">฿{order.agreed_price}</span>
                  ) : (
                    <span className="italic text-neutral-600">{t('pendingQuote')}</span>
                  )}
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Right Panel: Order detail */}
      <div className="flex-1 flex flex-col overflow-y-auto bg-white dark:bg-neutral-950">
        {selectedOrder ? (
          <div className="p-8 max-w-4xl w-full mx-auto space-y-8">
            {/* Header Info */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-neutral-50 dark:bg-neutral-900/30 p-6 rounded-3xl border border-neutral-200 dark:border-neutral-800">
              <div>
                <h1 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">{selectedOrder.title}</h1>
                <p className="text-neutral-600 dark:text-neutral-400 text-sm whitespace-pre-line">{selectedOrder.description}</p>
              </div>
              <div className="flex flex-col gap-2 items-end min-w-[120px]">
                <span className={`text-xs font-bold px-3 py-1 rounded-full border w-fit ${getStatusBadgeClass(selectedOrder.status)}`}>
                  {selectedOrder.status}
                </span>
                {selectedOrder.agreed_price ? (
                  <span className="text-xl font-bold text-blue-400">฿{selectedOrder.agreed_price}</span>
                ) : (
                  <span className="text-sm italic text-neutral-500 dark:text-neutral-500">{t('awaitingQuote')}</span>
                )}
              </div>
            </div>

            {/* Progress tracker */}
            {selectedOrder.status !== 'CANCELLED' && (
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('workflowProgress')}</h3>
                <div className="bg-neutral-100 dark:bg-neutral-900/20 border border-neutral-200 dark:border-neutral-900 p-6 rounded-2xl relative overflow-hidden">
                  <div className="flex justify-between text-xs text-neutral-600 dark:text-neutral-400 relative z-10 flex-wrap md:flex-nowrap gap-4">
                    {steps.map((step, idx) => {
                      const active = getStepIndex(selectedOrder.status) >= idx;
                      return (
                        <div key={step} className="flex flex-col items-center text-center flex-1 min-w-[70px]">
                          <div className={`w-8 h-8 rounded-full border flex items-center justify-center font-bold mb-2 transition-all ${
                            active ? 'bg-blue-600 border-blue-500 text-white shadow-md shadow-blue-500/20' : 'bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 text-neutral-600'
                          }`}>
                            {idx + 1}
                          </div>
                          <span className={`text-[10px] font-semibold uppercase tracking-wider ${active ? 'text-neutral-900 dark:text-white font-bold' : 'text-neutral-600'}`}>
                            {step}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Invoices Section */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('milestones')}</h3>
              {loadingInvoices ? (
                <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
              ) : invoices.length === 0 ? (
                <div className="bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-2xl p-6 text-center text-neutral-500 dark:text-neutral-500 text-sm">
                  {t('noInvoices')}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {invoices.map((inv) => (
                    <div key={inv.id} className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 rounded-2xl p-5 flex flex-col justify-between gap-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-bold text-neutral-900 dark:text-white text-sm">{inv.title}</h4>
                          <span className="text-neutral-500 dark:text-neutral-500 text-[10px]">{t('created')} {new Date(inv.created_at).toLocaleDateString()}</span>
                        </div>
                        <span className="text-lg font-bold text-blue-400">฿{inv.amount}</span>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-neutral-800/50">
                        {inv.is_paid ? (
                          <span className="flex items-center gap-1 text-xs text-emerald-400 font-bold bg-emerald-500/5 px-2.5 py-1 rounded-full border border-emerald-500/10">
                            <CheckCircle className="w-4 h-4" /> {t('paidConfirmed')}
                          </span>
                        ) : inv.slip_image_url ? (
                          <div className="flex flex-col gap-2 w-full">
                            <span className="flex items-center gap-1 text-xs text-yellow-400 font-bold bg-yellow-500/5 px-2.5 py-1 rounded-full border border-yellow-500/10 w-fit">
                              <FileCheck className="w-4 h-4" /> {t('awaitingReview')}
                            </span>
                            <div className="mt-2 w-full max-w-[120px] aspect-[3/4] rounded-lg overflow-hidden border border-neutral-200 dark:border-neutral-800 relative bg-neutral-50 dark:bg-neutral-900">
                              <SecureImage src={inv.slip_image_url} alt="Slip" className="w-full h-full object-cover" />
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between w-full">
                            <span className="text-xs text-amber-400 font-bold flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5" /> {t('unpaid')}
                            </span>
                            <label className="flex items-center gap-1 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-700 text-neutral-900 dark:text-white text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer border border-neutral-300 dark:border-neutral-700">
                              {uploadingSlipId === inv.id ? (
                                <Loader2 className="w-3 h-3 animate-spin text-blue-500" />
                              ) : (
                                <Upload className="w-3.5 h-3.5" />
                              )}
                              {t('uploadSlip')}
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleUploadSlip(inv.id, e)}
                                disabled={uploadingSlipId === inv.id}
                                className="hidden"
                              />
                            </label>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Files & Delivery Section */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('wipDrafts')}</h3>
              {loadingFiles ? (
                <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
              ) : files.length === 0 ? (
                <div className="bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-2xl p-6 text-center text-neutral-500 dark:text-neutral-500 text-sm">
                  {t('noFiles')}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {files.map((file) => (
                    <div key={file.id} className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 rounded-2xl overflow-hidden flex flex-col justify-between">
                      {/* Image Preview Block (for WIP and FINAL images) */}
                      {file.filename.match(/\.(jpeg|jpg|gif|png)$/i) ? (
                        <div className="aspect-video w-full relative bg-neutral-50 dark:bg-neutral-900 border-b border-neutral-200 dark:border-neutral-800 overflow-hidden group">
                          <SecureImage src={`/orders/${selectedOrderId}/files/${file.id}/download`} alt={file.filename} className="w-full h-full object-cover" />
                          {file.is_watermarked && (
                            <div className="absolute inset-0 bg-neutral-950/60 backdrop-blur-[1px] flex flex-col justify-center items-center gap-2 opacity-100 transition-opacity">
                              <span className="bg-blue-600/20 text-blue-400 text-[10px] font-bold border border-blue-500/20 px-2 py-0.5 rounded-md flex items-center gap-1 backdrop-blur-md">
                                <Lock className="w-3.5 h-3.5" /> {t('watermarked')}
                              </span>
                              <span className="text-[10px] text-neutral-600 dark:text-neutral-400 px-6 text-center">{t('unwatermarked')}</span>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="aspect-video w-full bg-neutral-50 dark:bg-neutral-900 border-b border-neutral-200 dark:border-neutral-800 flex flex-col items-center justify-center text-neutral-500 dark:text-neutral-500">
                          <FileText className="w-12 h-12 text-neutral-700 mb-2" />
                          <span className="text-xs text-neutral-600 dark:text-neutral-400 font-medium">{file.filename}</span>
                        </div>
                      )}

                      <div className="p-4 flex items-center justify-between bg-neutral-100 dark:bg-neutral-900/10">
                        <div>
                          <h4 className="font-bold text-neutral-900 dark:text-white text-xs truncate max-w-[150px]">{file.filename}</h4>
                          <span className="text-[9px] bg-neutral-800/80 border border-neutral-300 dark:border-neutral-700 px-1.5 py-0.5 rounded text-neutral-700 dark:text-neutral-300 uppercase tracking-widest font-bold mt-1 inline-block">
                            {file.file_type}
                          </span>
                        </div>
                        <button
                          onClick={() => handleDownload(file)}
                          className="flex items-center gap-1.5 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-700 text-neutral-900 dark:text-white text-xs font-bold px-3 py-2 rounded-xl transition-all cursor-pointer border border-neutral-300 dark:border-neutral-700"
                        >
                          <ArrowDownToLine className="w-4 h-4" /> {t('download')}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Revisions & Feedback loops */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('revisionsFeedbacks')}</h3>
                <span className="text-xs text-neutral-500 dark:text-neutral-500 font-semibold">
                  {t('remainingQuota')} <span className="text-neutral-900 dark:text-white font-bold">{selectedOrder.revision_quota - revisions.length}</span> / {selectedOrder.revision_quota}
                </span>
              </div>

              {/* Feedbacks list */}
              {revisions.length > 0 && (
                <div className="space-y-3 bg-neutral-100 dark:bg-neutral-900/20 p-5 rounded-2xl border border-neutral-200 dark:border-neutral-900">
                  {revisions.map((rev, idx) => (
                    <div key={rev.id} className="flex gap-3 text-sm border-b border-neutral-900/50 pb-3 last:border-b-0 last:pb-0">
                      <div className="w-6 h-6 rounded-full bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-bold text-xs flex items-center justify-center shrink-0">
                        {idx + 1}
                      </div>
                      <div className="flex-1">
                        <p className="text-neutral-700 dark:text-neutral-300 text-xs">{rev.client_feedback}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-[10px] text-neutral-500 dark:text-neutral-500">{new Date(rev.created_at).toLocaleString()}</span>
                          {rev.is_addressed ? (
                            <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                              {t('resolved')}
                            </span>
                          ) : (
                            <span className="text-[10px] text-amber-400 font-semibold bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
                              {t('awaitingAddress')}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Submit Revision Form */}
              {['SKETCHING', 'COLORING'].includes(selectedOrder.status) && revisions.length < selectedOrder.revision_quota && (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (revisionFeedback.trim()) {
                      submitRevisionMutation.mutate(revisionFeedback);
                    }
                  }}
                  className="space-y-3 bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 p-5 rounded-2xl"
                >
                  <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider">
                    {t('submitRevision')}
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Provide specific notes on what elements you want adjusted (e.g. make the hair darker, shift background lighting to warm)..."
                    value={revisionFeedback}
                    onChange={(e) => setRevisionFeedback(e.target.value)}
                    required
                    className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white text-xs rounded-xl p-3 placeholder-neutral-600 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={submitRevisionMutation.isPending}
                      className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-1 disabled:opacity-50"
                    >
                      {submitRevisionMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                      {t('submitBtn')}
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* Chat Section */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('messages')}</h3>
              <ChatBox orderId={selectedOrder.id} currentUserId={user.id} />
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <HelpCircle className="w-16 h-16 text-neutral-800 mb-4" />
            <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-2">{t('welcome')}</h2>
            <p className="text-neutral-500 dark:text-neutral-500 text-sm max-w-md">
              {t('welcomeDesc')}
            </p>
          </div>
        )}
      </div>

      {/* Create Order Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-8 shadow-2xl relative">
            <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-6">{t('newCommission')}</h2>
            <form onSubmit={handleCreateOrder} className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">
                  {t('projectTitle')}
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. VTuber Character Concept Art, Cyberpunk Banner"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-2xl py-3 px-4 placeholder-neutral-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">
                  {t('descBrief')}
                </label>
                <textarea
                  rows={5}
                  required
                  placeholder="Give a detailed description of your idea, canvas size/aspect ratio, preferred styling details, and references..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-2xl py-3 px-4 placeholder-neutral-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-sm"
                />
              </div>

              <div className="flex gap-4 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-700 text-neutral-900 dark:text-white font-semibold py-3 rounded-2xl transition-all cursor-pointer text-sm text-center"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  disabled={createOrderMutation.isPending}
                  className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-3 rounded-2xl transition-all flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer shadow-lg shadow-blue-600/20 text-sm"
                >
                  {createOrderMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
                  {t('submitBrief')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
