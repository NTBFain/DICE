'use client';

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getOrders,
  updateOrder,
  getInvoices,
  createInvoice,
  approveInvoice,
  getRevisions,
  resolveRevision,
  getFiles,
  uploadOrderFile,
  deleteOrderFile,
  getPortfolioAdmin,
  createArtwork,
  updateArtwork,
  deleteArtwork,
  getAuctions,
  createAuction,
  closeAuction,
  getCommissionStatus,
  updateCommissionStatus,
  Artwork,
  Auction,
  getCharacters,
  createCharacter,
  updateCharacter,
  deleteCharacter,
  Character,
} from '@/lib/api';
import { useAuth } from '@/components/AuthContext';
import { useRouter } from '@/i18n/routing';
import {
  Loader2,
  Calendar,
  Layers,
  ArrowRight,
  Upload,
  CheckCircle,
  FileText,
  User,
  Trash2,
  Image as ImageIcon,
  DollarSign,
  Briefcase,
  Layers3,
  HelpCircle,
  Check,
  X,
  FileCheck,
  Plus,
  RefreshCw,
  Gavel,
  Edit,
  Users,
} from 'lucide-react';

const WORK_TYPES = [
  { id: 'ILLUSTRATION', label: 'Illustration' },
  { id: 'SKETCH', label: 'Sketch & Doodle' },
  { id: 'COMIC', label: 'Comic' },
  { id: 'LIVE2D', label: 'Live2D' },
  { id: 'CONCEPT_ART', label: 'Concept Art' }
];
import SecureImage from '@/components/SecureImage';
import ChatBox from '@/components/ChatBox';
import AnalyticsPanel from './AnalyticsPanel';
import WatermarkPanel from './WatermarkPanel';
import { BarChart3 } from 'lucide-react';
import { useTranslations } from 'next-intl';

export default function AdminDashboard() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const t = useTranslations('AdminDashboard');
  const queryClient = useQueryClient();

  const [activeTab, setActiveTab] = useState<'orders' | 'portfolio' | 'auctions' | 'analytics' | 'characters' | 'watermark'>('orders');
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);

  // States for Invoice Creation
  const [invoiceTitle, setInvoiceTitle] = useState('');
  const [invoiceAmount, setInvoiceAmount] = useState('');

  // States for File Upload
  const [uploadFileType, setUploadFileType] = useState<'WIP' | 'FINAL' | 'REFERENCE'>('WIP');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadingFile, setUploadingFile] = useState(false);

  // States for Accepting Order / Setting price
  const [agreedPriceInput, setAgreedPriceInput] = useState('');

  // States for Portfolio Management
  const [showArtModal, setShowArtModal] = useState(false);
  const [artTitle, setArtTitle] = useState('');
  const [artDesc, setArtDesc] = useState('');
  const [artImgFile, setArtImgFile] = useState<File | null>(null);
  const [artVisibility, setArtVisibility] = useState('PUBLIC');
  const [artWorkType, setArtWorkType] = useState('ILLUSTRATION');
  const [artCharacterId, setArtCharacterId] = useState<number | null>(null);

  // States for Edit Artwork
  const [showEditArtModal, setShowEditArtModal] = useState(false);
  const [editingArtId, setEditingArtId] = useState<number | null>(null);
  const [editArtTitle, setEditArtTitle] = useState('');
  const [editArtDesc, setEditArtDesc] = useState('');
  const [editArtVisibility, setEditArtVisibility] = useState('PUBLIC');
  const [editArtWorkType, setEditArtWorkType] = useState('ILLUSTRATION');
  const [editArtCharacterId, setEditArtCharacterId] = useState<number | null>(null);

  // States for Auction Management
  const [showAuctionModal, setShowAuctionModal] = useState(false);
  const [auctionTitle, setAuctionTitle] = useState('');
  const [auctionDesc, setAuctionDesc] = useState('');
  const [auctionImgUrl, setAuctionImgUrl] = useState('');
  const [auctionType, setAuctionType] = useState<'COMMISSION_SLOT' | 'ADOPTABLE'>('ADOPTABLE');
  const [auctionStartingBid, setAuctionStartingBid] = useState('');
  const [auctionBidIncrement, setAuctionBidIncrement] = useState('');
  const [auctionAutoBuy, setAuctionAutoBuy] = useState('');
  const [auctionStartTime, setAuctionStartTime] = useState('');
  const [auctionEndTime, setAuctionEndTime] = useState('');

  // States for Character Management
  const [showCharModal, setShowCharModal] = useState(false);
  const [editingCharId, setEditingCharId] = useState<number | null>(null);
  const [charName, setCharName] = useState('');
  const [charDesc, setCharDesc] = useState('');
  const [charThemeColor, setCharThemeColor] = useState('#3B82F6'); // Default blue
  const [charImgFile, setCharImgFile] = useState<File | null>(null);

  // Redirect if not logged in or not admin
  useEffect(() => {
    if (!authLoading && (!user || !user.is_admin)) {
      router.push('/login');
    }
  }, [authLoading, user, router]);

  // --- QUERIES ---
  const { data: commissionStatus = { open: false }, isLoading: loadingStatus } = useQuery({
    queryKey: ['commission-status'],
    queryFn: getCommissionStatus,
  });

  const { data: orders = [], isLoading: loadingOrders, refetch: refetchOrders } = useQuery({
    queryKey: ['admin-orders'],
    queryFn: getOrders,
    enabled: !!user?.is_admin,
  });

  const selectedOrder = orders.find((o) => o.id === selectedOrderId);

  const { data: invoices = [], isLoading: loadingInvoices } = useQuery({
    queryKey: ['admin-order-invoices', selectedOrderId],
    queryFn: () => getInvoices(selectedOrderId!),
    enabled: !!selectedOrderId,
  });

  const { data: revisions = [], isLoading: loadingRevisions } = useQuery({
    queryKey: ['admin-order-revisions', selectedOrderId],
    queryFn: () => getRevisions(selectedOrderId!),
    enabled: !!selectedOrderId,
  });

  const { data: files = [], isLoading: loadingFiles } = useQuery({
    queryKey: ['admin-order-files', selectedOrderId],
    queryFn: () => getFiles(selectedOrderId!),
    enabled: !!selectedOrderId,
  });

  const { data: artworks = [], isLoading: loadingArtworks, refetch: refetchArtworks } = useQuery({
    queryKey: ['admin-portfolio'],
    queryFn: getPortfolioAdmin,
    enabled: !!user?.is_admin && activeTab === 'portfolio',
  });

  const { data: characters = [] } = useQuery({
    queryKey: ['characters'],
    queryFn: getCharacters,
    enabled: !!user?.is_admin,
  });

  const { data: auctions = [], isLoading: loadingAuctions, refetch: refetchAuctions } = useQuery({
    queryKey: ['admin-auctions'],
    queryFn: getAuctions,
    enabled: !!user?.is_admin && activeTab === 'auctions',
  });

  // --- MUTATIONS ---
  const toggleCommissionMutation = useMutation({
    mutationFn: updateCommissionStatus,
    onSuccess: (data) => {
      queryClient.setQueryData(['commission-status'], data);
    },
  });

  const updateOrderMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: { status?: Order['status']; agreed_price?: number; revision_quota?: number } }) => updateOrder(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-orders'] });
    },
  });

  const createInvoiceMutation = useMutation({
    mutationFn: (data: { title: string; amount: number }) => createInvoice(selectedOrderId!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-order-invoices', selectedOrderId] });
      setInvoiceTitle('');
      setInvoiceAmount('');
    },
  });

  const approveInvoiceMutation = useMutation({
    mutationFn: approveInvoice,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-order-invoices', selectedOrderId] });
      // Invalidate files since final file watermarking state depends on invoices payment status
      queryClient.invalidateQueries({ queryKey: ['admin-order-files', selectedOrderId] });
    },
  });

  const resolveRevisionMutation = useMutation({
    mutationFn: resolveRevision,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-order-revisions', selectedOrderId] });
    },
  });

  const deleteFileMutation = useMutation({
    mutationFn: (fileId: number) => deleteOrderFile(selectedOrderId!, fileId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-order-files', selectedOrderId] });
    },
  });

  const createArtworkMutation = useMutation({
    mutationFn: createArtwork,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-portfolio'] });
      setShowArtModal(false);
      setArtTitle('');
      setArtDesc('');
      setArtImgFile(null);
      setArtVisibility('PUBLIC');
      setArtWorkType('ILLUSTRATION');
      setArtCharacterId(null);
    },
  });

  const updateArtworkMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: any }) => updateArtwork(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-portfolio'] });
      setShowEditArtModal(false);
      setEditingArtId(null);
    },
  });

  const deleteArtworkMutation = useMutation({
    mutationFn: deleteArtwork,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-portfolio'] });
    },
  });

  const createAuctionMutation = useMutation({
    mutationFn: createAuction,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-auctions'] });
      setShowAuctionModal(false);
      setAuctionTitle('');
      setAuctionDesc('');
      setAuctionImgUrl('');
      setAuctionType('ADOPTABLE');
      setAuctionStartingBid('');
      setAuctionBidIncrement('');
      setAuctionAutoBuy('');
      setAuctionStartTime('');
      setAuctionEndTime('');
    },
  });

  const closeAuctionMutation = useMutation({
    mutationFn: closeAuction,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-auctions'] });
    },
  });

  const createCharacterMutation = useMutation({
    mutationFn: createCharacter,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
      setShowCharModal(false);
      setCharName('');
      setCharDesc('');
      setCharThemeColor('#3B82F6');
      setCharImgFile(null);
    },
  });

  const updateCharacterMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: any }) => updateCharacter(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
      setShowCharModal(false);
      setEditingCharId(null);
    },
  });

  const deleteCharacterMutation = useMutation({
    mutationFn: deleteCharacter,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['characters'] });
      queryClient.invalidateQueries({ queryKey: ['admin-portfolio'] }); // Refresh artworks that might be unlinked
    },
  });

  if (authLoading || !user || !user.is_admin) {
    return (
      <div className="flex-1 flex items-center justify-center p-20">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  // --- ACTIONS ---
  const handleUpdateStatus = (status: Order['status']) => {
    updateOrderMutation.mutate({ id: selectedOrderId!, data: { status } });
  };

  const handleSetPrice = (e: React.FormEvent) => {
    e.preventDefault();
    if (agreedPriceInput) {
      updateOrderMutation.mutate({
        id: selectedOrderId!,
        data: { agreed_price: parseFloat(agreedPriceInput), status: 'ACCEPTED' },
      });
      setAgreedPriceInput('');
    }
  };

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (invoiceTitle && invoiceAmount) {
      createInvoiceMutation.mutate({
        title: invoiceTitle,
        amount: parseFloat(invoiceAmount),
      });
    }
  };

  const handleUploadFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadFile) return;
    setUploadingFile(true);
    try {
      await uploadOrderFile(selectedOrderId!, uploadFileType, uploadFile);
      queryClient.invalidateQueries({ queryKey: ['admin-order-files', selectedOrderId] });
      setUploadFile(null);
    } catch (err) {
      console.error(err);
      alert('Failed to upload file');
    } finally {
      setUploadingFile(false);
    }
  };

  const handleCreateArtwork = (e: React.FormEvent) => {
    e.preventDefault();
    if (!artImgFile) {
      alert("Please select an image file first");
      return;
    }
    createArtworkMutation.mutate({
      title: artTitle,
      description: artDesc,
      image: artImgFile,
      visibility_status: artVisibility,
      work_type: artWorkType,
      character_id: artCharacterId,
    });
  };

  const openEditArtModal = (art: Artwork) => {
    setEditingArtId(art.id);
    setEditArtTitle(art.title);
    setEditArtDesc(art.description || '');
    setEditArtVisibility(art.visibility_status);
    setEditArtWorkType(art.work_type);
    setEditArtCharacterId(art.character_id || null);
    setShowEditArtModal(true);
  };

  const handleEditArtwork = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingArtId) return;
    updateArtworkMutation.mutate({
      id: editingArtId,
      data: {
        title: editArtTitle,
        description: editArtDesc,
        visibility_status: editArtVisibility,
        work_type: editArtWorkType,
        character_id: editArtCharacterId,
      }
    });
  };

  const handleCreateAuction = (e: React.FormEvent) => {
    e.preventDefault();
    createAuctionMutation.mutate({
      title: auctionTitle,
      description: auctionDesc,
      image_url: auctionImgUrl || undefined,
      auction_type: auctionType,
      starting_bid: parseFloat(auctionStartingBid),
      bid_increment: parseFloat(auctionBidIncrement),
      auto_buy: auctionAutoBuy ? parseFloat(auctionAutoBuy) : undefined,
      start_time: new Date(auctionStartTime).toISOString(),
      end_time: new Date(auctionEndTime).toISOString(),
    });
  };

  const openAddCharModal = () => {
    setEditingCharId(null);
    setCharName('');
    setCharDesc('');
    setCharThemeColor('#3B82F6');
    setCharImgFile(null);
    setShowCharModal(true);
  };

  const openEditCharModal = (char: Character) => {
    setEditingCharId(char.id);
    setCharName(char.name);
    setCharDesc(char.description || '');
    setCharThemeColor(char.theme_color || '#3B82F6');
    setCharImgFile(null);
    setShowCharModal(true);
  };

  const handleSaveCharacter = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCharId) {
      updateCharacterMutation.mutate({
        id: editingCharId,
        data: { name: charName, description: charDesc, theme_color: charThemeColor, image: charImgFile || undefined }
      });
    } else {
      createCharacterMutation.mutate({
        name: charName,
        description: charDesc,
        theme_color: charThemeColor,
        image: charImgFile || undefined
      });
    }
  };

  const getStatusBadgeClass = (status: Order['status']) => {
    switch (status) {
      case 'PENDING':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'ACCEPTED':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'SKETCHING':
        return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'COLORING':
        return 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20';
      case 'COMPLETED':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'CANCELLED':
        return 'bg-red-500/10 text-red-400 border-red-500/20';
    }
  };

  return (
    <div className="flex-1 flex flex-col h-[calc(100vh-4rem)] overflow-hidden bg-white dark:bg-neutral-950">
      {/* Top bar tabs */}
      <div className="border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/30 px-6 h-14 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-6 h-full">
          <button
            onClick={() => setActiveTab('orders')}
            className={`h-full text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-all ${
              activeTab === 'orders'
                ? 'border-blue-500 text-blue-400 font-extrabold'
                : 'border-transparent text-neutral-600 dark:text-neutral-400 hover:text-white'
            }`}
          >
            <Briefcase className="w-4 h-4" /> {t('commissions')}
          </button>
          <button
            onClick={() => setActiveTab('portfolio')}
            className={`h-full text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-all ${
              activeTab === 'portfolio'
                ? 'border-blue-500 text-blue-400 font-extrabold'
                : 'border-transparent text-neutral-600 dark:text-neutral-400 hover:text-white'
            }`}
          >
            <Layers3 className="w-4 h-4" /> {t('portfolioCrud')}
          </button>
          <button
            onClick={() => setActiveTab('characters')}
            className={`h-full text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-all ${
              activeTab === 'characters'
                ? 'border-blue-500 text-blue-400 font-extrabold'
                : 'border-transparent text-neutral-600 dark:text-neutral-400 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" /> Characters
          </button>
          <button
            onClick={() => setActiveTab('auctions')}
            className={`h-full text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-all ${
              activeTab === 'auctions'
                ? 'border-blue-500 text-blue-400 font-extrabold'
                : 'border-transparent text-neutral-600 dark:text-neutral-400 hover:text-white'
            }`}
          >
            <Gavel className="w-4 h-4" /> {t('auctions')}
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`h-full text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-all ${
              activeTab === 'analytics'
                ? 'border-blue-500 text-blue-400 font-extrabold'
                : 'border-transparent text-neutral-600 dark:text-neutral-400 hover:text-white'
            }`}
          >
            <BarChart3 className="w-4 h-4" /> {t('analytics')}
          </button>
          <button
            onClick={() => setActiveTab('watermark')}
            className={`h-full text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border-b-2 cursor-pointer transition-all ${
              activeTab === 'watermark'
                ? 'border-blue-500 text-blue-400 font-extrabold'
                : 'border-transparent text-neutral-600 dark:text-neutral-400 hover:text-white'
            }`}
          >
            <ImageIcon className="w-4 h-4" /> Watermark
          </button>
        </div>

        {/* Commission toggle button */}
        <div className="flex items-center gap-3">
          <span className="text-xs text-neutral-600 dark:text-neutral-400 font-medium">{t('commissionStatus')}</span>
          <button
            onClick={() => toggleCommissionMutation.mutate(!commissionStatus.open)}
            disabled={toggleCommissionMutation.isPending || loadingStatus}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all border cursor-pointer select-none ${
              commissionStatus.open
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20 shadow-[0_0_12px_rgba(16,185,129,0.1)]'
                : 'bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20 shadow-[0_0_12px_rgba(239,68,68,0.1)]'
            }`}
          >
            {toggleCommissionMutation.isPending || loadingStatus ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <span className={`w-2 h-2 rounded-full ${commissionStatus.open ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`} />
            )}
            {commissionStatus.open ? t('statusOpen') : t('statusClosed')}
          </button>
        </div>
      </div>

      {activeTab === 'orders' && (
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
          {/* Left panel: list of orders */}
          <div className="w-full lg:w-96 border-r border-neutral-200 dark:border-neutral-800 bg-neutral-100 dark:bg-neutral-900/20 flex flex-col overflow-y-auto">
            <div className="p-6 border-b border-neutral-200 dark:border-neutral-800 flex justify-between items-center bg-white dark:bg-neutral-950 sticky top-0 z-10">
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                {t('clientsCommissions')}
                <button
                  onClick={() => refetchOrders()}
                  className="text-neutral-500 dark:text-neutral-500 hover:text-neutral-900 dark:text-white transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </h2>
            </div>
            <div className="flex-1 p-4 space-y-3">
              {loadingOrders ? (
                <div className="flex justify-center py-20">
                  <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
                </div>
              ) : orders.length === 0 ? (
                <div className="text-center py-20 bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-2xl p-6">
                  <HelpCircle className="w-12 h-12 text-neutral-700 mx-auto mb-3" />
                  <h3 className="font-semibold text-neutral-500 dark:text-neutral-500">{t('noCommissionsYet')}</h3>
                </div>
              ) : (
                orders.map((order) => (
                  <button
                    key={order.id}
                    onClick={() => setSelectedOrderId(order.id)}
                    className={`w-full text-left p-4 rounded-2xl border transition-all cursor-pointer flex flex-col gap-2 ${
                      selectedOrderId === order.id
                        ? 'bg-neutral-50 dark:bg-neutral-900 border-neutral-300 dark:border-neutral-700 shadow-md shadow-black/40'
                        : 'bg-neutral-50 dark:bg-neutral-900/40 border-neutral-800/80 hover:bg-neutral-100 dark:bg-neutral-900/60 hover:border-neutral-200 dark:border-neutral-800'
                    }`}
                  >
                    <div className="flex justify-between items-start gap-2">
                      <h3 className="font-semibold text-neutral-900 dark:text-white truncate text-sm">
                        {order.title} {order.client_name && <span className="text-neutral-500 font-normal ml-1">({order.client_name})</span>}
                      </h3>
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full border ${getStatusBadgeClass(order.status)}`}>
                        {order.status}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-600 dark:text-neutral-400 line-clamp-1">{order.description}</p>
                    <div className="flex items-center justify-between text-[10px] text-neutral-500 dark:text-neutral-500 mt-1 pt-2 border-t border-neutral-800/50">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" /> {new Date(order.created_at).toLocaleDateString()}
                      </span>
                      {order.agreed_price ? (
                        <span className="text-blue-400 font-semibold">฿{order.agreed_price}</span>
                      ) : (
                        <span className="text-amber-500 font-semibold bg-amber-500/10 px-1 rounded">{t('newRequest')}</span>
                      )}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Right panel: order detail & action panel */}
          <div className="flex-1 flex flex-col overflow-y-auto bg-white dark:bg-neutral-950">
            {selectedOrder ? (
              <div className="p-8 max-w-4xl w-full mx-auto space-y-8 pb-20">
                {/* Header card */}
                <div className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 p-6 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadgeClass(selectedOrder.status)}`}>
                        {selectedOrder.status}
                      </span>
                      <span className="text-xs text-neutral-500 dark:text-neutral-500">
                        {t('client')} {selectedOrder.client_name || t('unknown')} (ID: {selectedOrder.client_id})
                      </span>
                    </div>
                    <h1 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">{selectedOrder.title}</h1>
                    <p className="text-neutral-600 dark:text-neutral-400 text-sm whitespace-pre-line">{selectedOrder.description}</p>
                  </div>

                  {selectedOrder.agreed_price ? (
                    <div className="text-right shrink-0">
                      <span className="text-xs text-neutral-500 dark:text-neutral-500 uppercase tracking-widest font-semibold block mb-1">{t('agreedPrice')}</span>
                      <span className="text-2xl font-bold text-blue-400">฿{selectedOrder.agreed_price}</span>
                    </div>
                  ) : (
                    <form onSubmit={handleSetPrice} className="bg-white dark:bg-neutral-950 p-4 border border-neutral-200 dark:border-neutral-800 rounded-2xl flex flex-col gap-3 min-w-[240px]">
                      <h4 className="text-xs font-bold text-neutral-900 dark:text-white">{t('acceptQuotePrice')}</h4>
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-neutral-500 dark:text-neutral-500 text-xs">
                            ฿
                          </span>
                          <input
                            type="number"
                            required
                            placeholder={t('price')}
                            value={agreedPriceInput}
                            onChange={(e) => setAgreedPriceInput(e.target.value)}
                            className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 pl-7 pr-2 placeholder-neutral-600 focus:outline-none text-xs"
                          />
                        </div>
                        <button
                          type="submit"
                          className="bg-blue-600 hover:bg-blue-500 text-white font-semibold px-4 py-2 rounded-xl text-xs cursor-pointer"
                        >
                          {t('accept')}
                        </button>
                      </div>
                    </form>
                  )}
                </div>

                {/* Workflow Transitions (Status Updates) */}
                {selectedOrder.status !== 'PENDING' && selectedOrder.status !== 'CANCELLED' && (
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('updateProjectStage')}</h3>
                    <div className="flex flex-wrap gap-3">
                      {['ACCEPTED', 'SKETCHING', 'COLORING', 'COMPLETED'].map((status) => (
                        <button
                          key={status}
                          onClick={() => handleUpdateStatus(status as Order['status'])}
                          className={`text-xs font-bold px-4 py-2.5 rounded-xl border transition-all cursor-pointer ${
                            selectedOrder.status === status
                              ? 'bg-blue-600 border-blue-500 text-white shadow-md shadow-blue-500/25'
                              : 'bg-neutral-100 dark:bg-neutral-900/60 border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:bg-neutral-900 hover:text-white'
                          }`}
                        >
                          {status}
                        </button>
                      ))}
                      <div className="w-px h-6 bg-neutral-200 dark:bg-neutral-800 mx-2 self-center"></div>
                      <button
                        onClick={() => handleUpdateStatus('CANCELLED')}
                        className="text-xs font-bold px-4 py-2.5 rounded-xl border border-red-900/30 bg-red-950/10 text-red-400 hover:bg-red-950/20 cursor-pointer"
                      >
                        {t('cancelProject')}
                      </button>
                    </div>
                  </div>
                )}

                {/* Invoices management */}
                {selectedOrder.status !== 'PENDING' && (
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('milestoneInvoices')}</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Left: Invoice creation form */}
                      <form onSubmit={handleCreateInvoice} className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 p-5 rounded-2xl space-y-4 h-fit">
                        <h4 className="font-bold text-neutral-900 dark:text-white text-xs uppercase tracking-wider">{t('newMilestone')}</h4>
                        <div>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Deposit 50%, Final Balance"
                            value={invoiceTitle}
                            onChange={(e) => setInvoiceTitle(e.target.value)}
                            className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 placeholder-neutral-600 focus:outline-none text-xs"
                          />
                        </div>
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-neutral-500 dark:text-neutral-500 text-xs">
                            ฿
                          </span>
                          <input
                            type="number"
                            required
                            placeholder={t('amount')}
                            value={invoiceAmount}
                            onChange={(e) => setInvoiceAmount(e.target.value)}
                            className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 pl-7 pr-3 placeholder-neutral-600 focus:outline-none text-xs"
                          />
                        </div>
                        <button
                          type="submit"
                          disabled={createInvoiceMutation.isPending}
                          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-1"
                        >
                          {createInvoiceMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                          {t('createInvoice')}
                        </button>
                      </form>

                      {/* Right: Invoices list */}
                      <div className="md:col-span-2 space-y-3">
                        {loadingInvoices ? (
                          <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
                        ) : invoices.length === 0 ? (
                          <div className="bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-2xl p-6 text-center text-neutral-500 dark:text-neutral-500 text-xs h-full flex items-center justify-center">
                            {t('noMilestoneInvoices')}
                          </div>
                        ) : (
                          invoices.map((inv) => (
                            <div key={inv.id} className="bg-neutral-100 dark:bg-neutral-900/20 border border-neutral-800/80 p-4 rounded-xl flex items-center justify-between flex-wrap gap-4">
                              <div>
                                <h5 className="font-bold text-neutral-900 dark:text-white text-xs">{inv.title}</h5>
                                <span className="text-[10px] text-neutral-500 dark:text-neutral-500">฿{inv.amount}</span>
                              </div>

                              <div className="flex items-center gap-3">
                                {inv.is_paid ? (
                                  <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                                    <Check className="w-3.5 h-3.5" /> {t('confirmedPaid')}
                                  </span>
                                ) : inv.slip_image_url ? (
                                  <div className="flex items-center gap-3">
                                    {/* Preview slip */}
                                    <a
                                      href={inv.slip_image_url}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="w-8 h-8 rounded border border-neutral-300 dark:border-neutral-700 overflow-hidden relative block bg-neutral-50 dark:bg-neutral-900 hover:scale-105 transition-transform"
                                    >
                                      <SecureImage src={inv.slip_image_url} alt="Slip" className="w-full h-full object-cover" />
                                    </a>
                                    <button
                                      onClick={() => approveInvoiceMutation.mutate(inv.id)}
                                      disabled={approveInvoiceMutation.isPending}
                                      className="bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-lg transition-all cursor-pointer flex items-center gap-0.5"
                                    >
                                      {approveInvoiceMutation.isPending ? (
                                        <Loader2 className="w-3 h-3 animate-spin" />
                                      ) : (
                                        <Check className="w-3.5 h-3.5" />
                                      )}
                                      {t('approvePaid')}
                                    </button>
                                  </div>
                                ) : (
                                  <span className="text-[10px] text-amber-400 font-bold bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                                    <X className="w-3.5 h-3.5" /> {t('unpaidNoSlip')}
                                  </span>
                                )}
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Upload Files Section */}
                {selectedOrder.status !== 'PENDING' && (
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('deliverWork')}</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {/* Left: Upload file form */}
                      <form onSubmit={handleUploadFile} className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 p-5 rounded-2xl space-y-4 h-fit">
                        <h4 className="font-bold text-neutral-900 dark:text-white text-xs uppercase tracking-wider">{t('uploadFile')}</h4>
                        
                        <div>
                          <label className="block text-[10px] font-semibold text-neutral-600 dark:text-neutral-400 uppercase mb-1">{t('fileType')}</label>
                          <select
                            value={uploadFileType}
                            onChange={(e) => setUploadFileType(e.target.value as 'WIP' | 'FINAL' | 'REFERENCE')}
                            className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 focus:outline-none text-xs"
                          >
                            <option value="WIP">{t('wipType')}</option>
                            <option value="FINAL">{t('finalType')}</option>
                            <option value="REFERENCE">{t('refType')}</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[10px] font-semibold text-neutral-600 dark:text-neutral-400 uppercase mb-1">{t('selectFile')}</label>
                          <input
                            type="file"
                            required
                            onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                            className="w-full text-xs text-neutral-500 dark:text-neutral-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-neutral-200 dark:bg-neutral-800 file:text-neutral-900 dark:text-white file:cursor-pointer hover:file:bg-neutral-700"
                          />
                        </div>

                        <button
                          type="submit"
                          disabled={uploadingFile || !uploadFile}
                          className="w-full bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-1 disabled:opacity-50"
                        >
                          {uploadingFile ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              {t('uploading')}
                            </>
                          ) : (
                            <>
                              <Upload className="w-3.5 h-3.5" />
                              {t('uploadFile')}
                            </>
                          )}
                        </button>
                      </form>

                      {/* Right: Files list */}
                      <div className="md:col-span-2 space-y-3">
                        {loadingFiles ? (
                          <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
                        ) : files.length === 0 ? (
                          <div className="bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-2xl p-6 text-center text-neutral-500 dark:text-neutral-500 text-xs h-full flex items-center justify-center">
                            {t('noFiles')}
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {files.map((file) => (
                              <div key={file.id} className="bg-neutral-100 dark:bg-neutral-900/20 border border-neutral-200 dark:border-neutral-800 rounded-xl overflow-hidden flex flex-col justify-between">
                                {file.filename.match(/\.(jpeg|jpg|gif|png)$/i) ? (
                                  <div className="aspect-video relative w-full bg-neutral-50 dark:bg-neutral-900 border-b border-neutral-850">
                                    <SecureImage src={`/orders/${selectedOrderId}/files/${file.id}/download`} alt={file.filename} className="w-full h-full object-cover" />
                                    {file.is_watermarked && (
                                      <span className="absolute top-2 right-2 bg-blue-600/30 text-blue-300 border border-blue-500/20 text-[9px] font-bold px-1.5 py-0.5 rounded backdrop-blur-md">
                                        {t('watermarkedBadge')}
                                      </span>
                                    )}
                                  </div>
                                ) : (
                                  <div className="aspect-video w-full bg-neutral-905 border-b border-neutral-850 flex items-center justify-center text-neutral-600">
                                    <FileText className="w-8 h-8" />
                                  </div>
                                )}
                                <div className="p-3 flex justify-between items-center">
                                  <div className="truncate max-w-[130px]">
                                    <h5 className="font-bold text-neutral-900 dark:text-white text-[11px] truncate">{file.filename}</h5>
                                    <span className="text-[9px] text-neutral-600 dark:text-neutral-400 font-semibold uppercase">{file.file_type}</span>
                                  </div>
                                  {file.file_type === 'WIP' && (
                                    <button
                                      onClick={() => {
                                        if (window.confirm('Are you sure you want to delete this WIP file?')) {
                                          deleteFileMutation.mutate(file.id);
                                        }
                                      }}
                                      disabled={deleteFileMutation.isPending}
                                      className="text-red-500 hover:text-red-400 p-1.5 rounded-lg bg-red-500/5 hover:bg-red-500/10 transition-colors"
                                      title="Delete WIP file"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Revisions from Clients */}
                {selectedOrder.status !== 'PENDING' && (
                  <div className="space-y-4">
                    <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('clientRevisions')}</h3>
                    
                    {loadingRevisions ? (
                      <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
                    ) : revisions.length === 0 ? (
                      <div className="bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-2xl p-6 text-center text-neutral-500 dark:text-neutral-500 text-xs">
                        {t('noRevisions')}
                      </div>
                    ) : (
                      <div className="space-y-3 bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 p-5 rounded-2xl">
                        {revisions.map((rev, idx) => (
                          <div key={rev.id} className="flex gap-4 border-b border-neutral-200 dark:border-neutral-900 pb-3 last:border-b-0 last:pb-0 text-sm">
                            <div className="w-6 h-6 rounded-full bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-bold text-xs flex items-center justify-center shrink-0">
                              {idx + 1}
                            </div>
                            <div className="flex-1">
                              <p className="text-neutral-700 dark:text-neutral-300 text-xs">{rev.client_feedback}</p>
                              <div className="flex items-center justify-between mt-2">
                                <span className="text-[10px] text-neutral-500 dark:text-neutral-500">{new Date(rev.created_at).toLocaleString()}</span>
                                {rev.is_addressed ? (
                                  <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                                    {t('addressedFixed')}
                                  </span>
                                ) : (
                                  <button
                                    onClick={() => resolveRevisionMutation.mutate(rev.id)}
                                    className="bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full cursor-pointer transition-colors"
                                  >
                                    {t('markAddressed')}
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Chat Section */}
                <div className="space-y-4">
                  <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">{t('messages')}</h3>
                  <ChatBox orderId={selectedOrder.id} currentUserId={user.id} />
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
                <Briefcase className="w-16 h-16 text-neutral-800 mb-4" />
                <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-2">{t('commissionsPanel')}</h2>
                <p className="text-neutral-500 dark:text-neutral-500 text-sm max-w-md">
                  {t('selectClientDesc')}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'portfolio' && (
        <div className="flex-1 flex flex-col overflow-y-auto p-8 max-w-6xl w-full mx-auto space-y-6">
          <div className="flex justify-between items-center border-b border-neutral-200 dark:border-neutral-800 pb-4">
            <div>
              <h2 className="text-xl font-bold text-neutral-900 dark:text-white">{t('managePortfolio')}</h2>
              <p className="text-neutral-600 dark:text-neutral-400 text-xs mt-1">{t('managePortfolioDesc')}</p>
            </div>
            <button
              onClick={() => setShowArtModal(true)}
              className="flex items-center gap-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all cursor-pointer shadow-lg shadow-blue-600/15"
            >
              <Plus className="w-4 h-4" /> {t('addArtwork')}
            </button>
          </div>

          {loadingArtworks ? (
            <div className="flex justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
            </div>
          ) : artworks.length === 0 ? (
            <div className="text-center py-20 bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-3xl">
              <ImageIcon className="w-16 h-16 text-neutral-800 mx-auto mb-4" />
              <h3 className="font-bold text-neutral-600 dark:text-neutral-400">{t('portfolioEmpty')}</h3>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {artworks.map((art) => (
                <div key={art.id} className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 rounded-2xl overflow-hidden flex flex-col group relative">
                  <div className="aspect-video w-full overflow-hidden bg-neutral-50 dark:bg-neutral-900 border-b border-neutral-200 dark:border-neutral-800 relative">
                    <img
                      src={art.image_url.startsWith('/') ? `http://127.0.0.1:8080${art.image_url}` : art.image_url}
                      alt={art.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <span className="absolute top-2 left-2 bg-black/60 border border-neutral-200 dark:border-neutral-800 text-[9px] font-bold px-1.5 py-0.5 rounded backdrop-blur-md uppercase text-neutral-700 dark:text-neutral-300">
                      {art.visibility_status}
                    </span>
                  </div>
                  <div className="p-4 flex justify-between items-start gap-4">
                    <div>
                      <h4 className="font-bold text-neutral-900 dark:text-white text-sm">{art.title}</h4>
                      <div className="flex gap-2 items-center mt-1">
                        <span className="text-[10px] font-bold text-blue-500 bg-blue-500/10 px-1.5 py-0.5 rounded uppercase">{art.work_type}</span>
                        {art.character && (
                          <span className="text-[10px] font-bold text-purple-500 bg-purple-500/10 px-1.5 py-0.5 rounded">{art.character.name}</span>
                        )}
                      </div>
                      {art.description && <p className="text-neutral-600 dark:text-neutral-400 text-xs mt-1 line-clamp-2">{art.description}</p>}
                    </div>
                    <div className="flex gap-1">
                      <button
                        onClick={() => openEditArtModal(art)}
                        className="text-blue-500 hover:text-blue-400 p-2 rounded-lg bg-blue-500/5 hover:bg-blue-500/10 border border-blue-500/10 hover:border-blue-500/20 transition-all cursor-pointer"
                        title="Edit Artwork"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if(window.confirm('Are you sure you want to delete this artwork?')) {
                            deleteArtworkMutation.mutate(art.id);
                          }
                        }}
                        className="text-red-500 hover:text-red-400 p-2 rounded-lg bg-red-500/5 hover:bg-red-500/10 border border-red-500/10 hover:border-red-500/20 transition-all cursor-pointer"
                        title="Delete Artwork"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Add Artwork Modal */}
          {showArtModal && (
            <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="w-full max-w-lg bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-8 shadow-2xl relative">
                <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-6">{t('addArtwork')}</h2>
                
                <form onSubmit={handleCreateArtwork} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('title')}</label>
                    <input
                      type="text"
                      required
                      placeholder="Cyberpunk Concept Art"
                      value={artTitle}
                      onChange={(e) => setArtTitle(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs placeholder-neutral-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('description')}</label>
                    <textarea
                      rows={3}
                      placeholder="Describe this artwork (optional)..."
                      value={artDesc}
                      onChange={(e) => setArtDesc(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs placeholder-neutral-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('imageFile')}</label>
                    <input
                      type="file"
                      required
                      accept="image/*"
                      onChange={(e) => setArtImgFile(e.target.files?.[0] || null)}
                      className="w-full text-xs text-neutral-500 dark:text-neutral-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-neutral-200 dark:bg-neutral-800 file:text-neutral-900 dark:text-white file:cursor-pointer hover:file:bg-neutral-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('visibility')}</label>
                    <select
                      value={artVisibility}
                      onChange={(e) => setArtVisibility(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                    >
                      <option value="PUBLIC">PUBLIC</option>
                      <option value="PRIVATE">PRIVATE</option>
                      <option value="CLIENT_ONLY">CLIENT_ONLY</option>
                      <option value="LINK_ONLY">LINK_ONLY</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">Work Type</label>
                      <select
                        value={artWorkType}
                        onChange={(e) => setArtWorkType(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                      >
                        {WORK_TYPES.map(wt => (
                          <option key={wt.id} value={wt.id}>{wt.label}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">Character</label>
                      <select
                        value={artCharacterId || ''}
                        onChange={(e) => setArtCharacterId(e.target.value ? parseInt(e.target.value) : null)}
                        className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                      >
                        <option value="">-- No Character --</option>
                        {characters.map(char => (
                          <option key={char.id} value={char.id}>{char.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowArtModal(false)}
                      className="flex-1 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-700 text-neutral-900 dark:text-white font-semibold py-2.5 rounded-xl transition-all cursor-pointer text-xs"
                    >
                      {t('cancel')}
                    </button>
                    <button
                      type="submit"
                      disabled={createArtworkMutation.isPending}
                      className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer text-xs shadow-lg shadow-blue-600/15"
                    >
                      {createArtworkMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                      {t('addArtwork')}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Edit Artwork Modal */}
          {showEditArtModal && (
            <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="w-full max-w-lg bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-8 shadow-2xl relative">
                <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-6">Edit Artwork</h2>
                
                <form onSubmit={handleEditArtwork} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('title')}</label>
                    <input
                      type="text"
                      required
                      placeholder="Cyberpunk Concept Art"
                      value={editArtTitle}
                      onChange={(e) => setEditArtTitle(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs placeholder-neutral-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('description')}</label>
                    <textarea
                      rows={3}
                      placeholder="Describe this artwork (optional)..."
                      value={editArtDesc}
                      onChange={(e) => setEditArtDesc(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs placeholder-neutral-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('visibility')}</label>
                    <select
                      value={editArtVisibility}
                      onChange={(e) => setEditArtVisibility(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                    >
                      <option value="PUBLIC">PUBLIC</option>
                      <option value="PRIVATE">PRIVATE</option>
                      <option value="CLIENT_ONLY">CLIENT_ONLY</option>
                      <option value="LINK_ONLY">LINK_ONLY</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">Work Type</label>
                      <select
                        value={editArtWorkType}
                        onChange={(e) => setEditArtWorkType(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                      >
                        {WORK_TYPES.map(wt => (
                          <option key={wt.id} value={wt.id}>{wt.label}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">Character</label>
                      <select
                        value={editArtCharacterId || ''}
                        onChange={(e) => setEditArtCharacterId(e.target.value ? parseInt(e.target.value) : null)}
                        className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                      >
                        <option value="">-- No Character --</option>
                        {characters.map(char => (
                          <option key={char.id} value={char.id}>{char.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowEditArtModal(false)}
                      className="flex-1 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-700 text-neutral-900 dark:text-white font-semibold py-2.5 rounded-xl transition-all cursor-pointer text-xs"
                    >
                      {t('cancel')}
                    </button>
                    <button
                      type="submit"
                      disabled={updateArtworkMutation.isPending}
                      className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer text-xs shadow-lg shadow-blue-600/15"
                    >
                      {updateArtworkMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                      Save Changes
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'auctions' && (
        <div className="flex-1 flex flex-col overflow-y-auto p-8 max-w-6xl w-full mx-auto space-y-6">
          <div className="flex justify-between items-center border-b border-neutral-200 dark:border-neutral-800 pb-4">
            <div>
              <h2 className="text-xl font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Gavel className="text-blue-500 w-6 h-6" /> {t('manageAuctions')}
              </h2>
              <p className="text-neutral-600 dark:text-neutral-400 text-xs mt-1">{t('manageAuctionsDesc')}</p>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => refetchAuctions()}
                className="text-neutral-500 dark:text-neutral-500 hover:text-neutral-900 dark:text-white transition-colors cursor-pointer p-2 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900/40"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setShowAuctionModal(true)}
                className="flex items-center gap-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all cursor-pointer shadow-lg shadow-blue-600/15"
              >
                <Plus className="w-4 h-4" /> {t('createAuction')}
              </button>
            </div>
          </div>

          {loadingAuctions ? (
            <div className="flex justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
            </div>
          ) : auctions.length === 0 ? (
            <div className="text-center py-20 bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-3xl">
              <Gavel className="w-16 h-16 text-neutral-800 mx-auto mb-4" />
              <h3 className="font-bold text-neutral-600 dark:text-neutral-400">{t('noAuctions')}</h3>
              <p className="text-neutral-500 dark:text-neutral-500 text-xs mt-1">{t('clickCreateAuction')}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {auctions.map((auction) => {
                const highestBid = auction.bids && auction.bids.length > 0 ? auction.bids[0].amount : null;
                const currentPrice = highestBid ?? auction.starting_bid;
                
                return (
                  <div key={auction.id} className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 rounded-2xl overflow-hidden flex flex-col group relative">
                    {auction.auction_type === 'ADOPTABLE' && auction.image_url ? (
                      <div className="aspect-video w-full overflow-hidden bg-neutral-50 dark:bg-neutral-900 border-b border-neutral-200 dark:border-neutral-800 relative">
                        <img
                          src={auction.image_url.startsWith('/') ? `http://127.0.0.1:8080${auction.image_url}` : auction.image_url}
                          alt={auction.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                    ) : (
                      <div className="aspect-video w-full bg-white dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-800 flex flex-col items-center justify-center text-neutral-600 p-4">
                        <Gavel className="w-12 h-12 mb-2 text-neutral-700" />
                        <span className="text-xs font-semibold text-neutral-500 dark:text-neutral-500 uppercase tracking-widest text-center">Commission Slot</span>
                      </div>
                    )}

                    <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                      <div>
                        <div className="flex justify-between items-center gap-2 mb-2">
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                            auction.auction_type === 'COMMISSION_SLOT'
                              ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'
                              : 'bg-purple-500/10 text-purple-400 border-purple-500/20'
                          }`}>
                            {auction.auction_type === 'COMMISSION_SLOT' ? t('slot') : t('adoptable')}
                          </span>
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border uppercase ${
                            auction.status === 'ACTIVE'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                              : 'bg-neutral-500/10 text-neutral-600 dark:text-neutral-400 border-neutral-500/20'
                          }`}>
                            {auction.status}
                          </span>
                        </div>

                        <h4 className="font-bold text-neutral-900 dark:text-white text-base truncate">{auction.title}</h4>
                        <p className="text-neutral-600 dark:text-neutral-400 text-xs mt-1 line-clamp-2">{auction.description}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs border-t border-neutral-800/60 pt-3">
                        <div>
                          <span className="text-neutral-500 dark:text-neutral-500 block text-[10px]">{t('startingBid')}</span>
                          <span className="text-neutral-900 dark:text-white font-medium">฿{auction.starting_bid}</span>
                        </div>
                        <div>
                          <span className="text-neutral-500 dark:text-neutral-500 block text-[10px]">{t('bidIncrement')}</span>
                          <span className="text-neutral-900 dark:text-white font-medium">฿{auction.bid_increment}</span>
                        </div>
                        <div>
                          <span className="text-neutral-500 dark:text-neutral-500 block text-[10px]">{t('autoBuy')}</span>
                          <span className="text-blue-400 font-semibold">{auction.auto_buy ? `฿${auction.auto_buy}` : 'None'}</span>
                        </div>
                        <div>
                          <span className="text-neutral-500 dark:text-neutral-500 block text-[10px]">{t('currentPrice')}</span>
                          <span className="text-emerald-400 font-bold">฿{currentPrice}</span>
                        </div>
                      </div>

                      {auction.winner_id && (
                        <div className="bg-emerald-500/5 border border-emerald-500/10 p-2.5 rounded-xl text-[11px] text-emerald-400 flex items-center justify-between">
                          <span>Winner ID: <strong className="text-neutral-900 dark:text-white">{auction.winner_id}</strong></span>
                          <span>Winning Bid: <strong>฿{auction.winning_bid}</strong></span>
                        </div>
                      )}

                      <div className="text-[10px] text-neutral-500 dark:text-neutral-500 border-t border-neutral-800/40 pt-2 flex flex-col gap-0.5">
                        <div>{t('starts')} {new Date(auction.start_time).toLocaleString()}</div>
                        <div>{t('ends')} {new Date(auction.end_time).toLocaleString()}</div>
                      </div>

                      {/* Bids history list */}
                      <div className="border-t border-neutral-850 pt-3">
                        <span className="text-[10px] uppercase tracking-wider font-bold text-neutral-600 dark:text-neutral-400 mb-1.5 block">{t('bidHistory')} ({auction.bids?.length || 0})</span>
                        {!auction.bids || auction.bids.length === 0 ? (
                          <span className="text-[10px] text-neutral-600 block italic">{t('noBidsPlaced')}</span>
                        ) : (
                          <div className="max-h-24 overflow-y-auto space-y-1.5 scrollbar-thin">
                            {auction.bids.map((b) => (
                              <div key={b.id} className="flex justify-between items-center text-[10px] bg-neutral-950/40 p-1.5 rounded-lg border border-neutral-850">
                                <span className="text-neutral-700 dark:text-neutral-300 font-medium truncate max-w-[120px]">{b.bidder_name}</span>
                                <span className="text-emerald-400 font-bold">฿{b.amount}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {auction.status === 'ACTIVE' && (
                        <button
                          onClick={() => closeAuctionMutation.mutate(auction.id)}
                          disabled={closeAuctionMutation.isPending}
                          className="w-full bg-red-600/10 hover:bg-red-600/20 text-red-400 border border-red-500/20 hover:border-red-500/30 text-xs font-bold py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 mt-2"
                        >
                          {closeAuctionMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                          {t('endAuctionManually')}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Add Auction Modal */}
          {showAuctionModal && (
            <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="w-full max-w-lg bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto scrollbar-thin">
                <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-6">{t('createNewAuction')}</h2>
                
                <form onSubmit={handleCreateAuction} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('auctionTitle')}</label>
                    <input
                      type="text"
                      required
                      placeholder="Adoptable #42: Celestial Dragon"
                      value={auctionTitle}
                      onChange={(e) => setAuctionTitle(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs placeholder-neutral-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('description')}</label>
                    <textarea
                      rows={3}
                      required
                      placeholder="Specify rights, references, and slot details..."
                      value={auctionDesc}
                      onChange={(e) => setAuctionDesc(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs placeholder-neutral-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('auctionType')}</label>
                    <select
                      value={auctionType}
                      onChange={(e) => setAuctionType(e.target.value as 'COMMISSION_SLOT' | 'ADOPTABLE')}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                    >
                      <option value="ADOPTABLE">ADOPTABLE (Character Sale)</option>
                      <option value="COMMISSION_SLOT">COMMISSION_SLOT (Work Queue)</option>
                    </select>
                  </div>

                  {auctionType === 'ADOPTABLE' && (
                    <div>
                      <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('imageUrl')}</label>
                      <input
                        type="url"
                        placeholder="https://images.unsplash.com/... or direct image link"
                        value={auctionImgUrl}
                        onChange={(e) => setAuctionImgUrl(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs placeholder-neutral-600 focus:outline-none"
                      />
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('startingBid')} (SB) ($)</label>
                      <input
                        type="number"
                        required
                        min="0"
                        placeholder="50"
                        value={auctionStartingBid}
                        onChange={(e) => setAuctionStartingBid(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('bidIncrement')} (BI) ($)</label>
                      <input
                        type="number"
                        required
                        min="1"
                        placeholder="5"
                        value={auctionBidIncrement}
                        onChange={(e) => setAuctionBidIncrement(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('autoBuy')} (AB) ($ - Optional)</label>
                    <input
                      type="number"
                      min="0"
                      placeholder="200 (Leave blank for no AB)"
                      value={auctionAutoBuy}
                      onChange={(e) => setAuctionAutoBuy(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('startTime')}</label>
                      <input
                        type="datetime-local"
                        required
                        value={auctionStartTime}
                        onChange={(e) => setAuctionStartTime(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">{t('endTime')}</label>
                      <input
                        type="datetime-local"
                        required
                        value={auctionEndTime}
                        onChange={(e) => setAuctionEndTime(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowAuctionModal(false)}
                      className="flex-1 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-700 text-neutral-900 dark:text-white font-semibold py-2.5 rounded-xl transition-all cursor-pointer text-xs"
                    >
                      {t('cancel')}
                    </button>
                    <button
                      type="submit"
                      disabled={createAuctionMutation.isPending}
                      className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer text-xs shadow-lg shadow-blue-600/15"
                    >
                      {createAuctionMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                      {t('startAuction')}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}
      {activeTab === 'characters' && (
        <div className="flex-1 flex flex-col overflow-y-auto p-8 max-w-6xl w-full mx-auto space-y-6">
          <div className="flex justify-between items-center border-b border-neutral-200 dark:border-neutral-800 pb-4">
            <div>
              <h2 className="text-xl font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Users className="text-blue-500 w-6 h-6" /> Manage Characters
              </h2>
              <p className="text-neutral-600 dark:text-neutral-400 text-xs mt-1">Add, edit, or remove characters from your universe.</p>
            </div>
            <button
              onClick={openAddCharModal}
              className="flex items-center gap-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all cursor-pointer shadow-lg shadow-blue-600/15"
            >
              <Plus className="w-4 h-4" /> Add Character
            </button>
          </div>

          {characters.length === 0 ? (
            <div className="text-center py-20 bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-3xl">
              <Users className="w-16 h-16 text-neutral-800 mx-auto mb-4" />
              <h3 className="font-bold text-neutral-600 dark:text-neutral-400">No Characters Yet</h3>
              <p className="text-neutral-500 dark:text-neutral-500 text-xs mt-1">Create your first character to associate them with artworks.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {characters.map((char) => (
                <div key={char.id} className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 rounded-2xl overflow-hidden flex flex-col relative group">
                  {char.image_url ? (
                    <div className="aspect-video w-full overflow-hidden bg-neutral-900 border-b border-neutral-200 dark:border-neutral-800">
                      <img
                        src={char.image_url.startsWith('/') ? `http://127.0.0.1:8080${char.image_url}` : char.image_url}
                        alt={char.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  ) : (
                    <div className="h-2 w-full" style={{ backgroundColor: char.theme_color || '#3B82F6' }}></div>
                  )}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                      <h4 className="font-bold text-neutral-900 dark:text-white text-base truncate">{char.name}</h4>
                      {char.description && <p className="text-neutral-600 dark:text-neutral-400 text-xs mt-2 line-clamp-3">{char.description}</p>}
                    </div>
                    <div className="flex gap-2 border-t border-neutral-200 dark:border-neutral-800 pt-4">
                      <button
                        onClick={() => openEditCharModal(char)}
                        className="flex-1 flex justify-center items-center gap-1 text-blue-500 hover:text-blue-400 p-2 rounded-lg bg-blue-500/5 hover:bg-blue-500/10 border border-blue-500/10 hover:border-blue-500/20 transition-all cursor-pointer text-xs font-bold"
                      >
                        <Edit className="w-3.5 h-3.5" /> Edit
                      </button>
                      <button
                        onClick={() => {
                          if(window.confirm(`Are you sure you want to delete ${char.name}?`)) {
                            deleteCharacterMutation.mutate(char.id);
                          }
                        }}
                        className="flex-1 flex justify-center items-center gap-1 text-red-500 hover:text-red-400 p-2 rounded-lg bg-red-500/5 hover:bg-red-500/10 border border-red-500/10 hover:border-red-500/20 transition-all cursor-pointer text-xs font-bold"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Character Modal */}
          {showCharModal && (
            <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="w-full max-w-lg bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-8 shadow-2xl relative">
                <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-6">
                  {editingCharId ? 'Edit Character' : 'Add Character'}
                </h2>
                
                <form onSubmit={handleSaveCharacter} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">Character Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. John Doe"
                      value={charName}
                      onChange={(e) => setCharName(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs placeholder-neutral-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">Description</label>
                    <textarea
                      rows={3}
                      placeholder="Background story or details..."
                      value={charDesc}
                      onChange={(e) => setCharDesc(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 px-3 text-xs placeholder-neutral-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">Character Image (Optional)</label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setCharImgFile(e.target.files?.[0] || null)}
                      className="w-full text-xs text-neutral-500 dark:text-neutral-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-neutral-200 dark:bg-neutral-800 file:text-neutral-900 dark:text-white file:cursor-pointer hover:file:bg-neutral-700"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wider mb-2">Theme Color</label>
                    <div className="flex gap-3 items-center">
                      <input
                        type="color"
                        value={charThemeColor}
                        onChange={(e) => setCharThemeColor(e.target.value)}
                        className="w-10 h-10 rounded cursor-pointer bg-transparent border-0 p-0"
                      />
                      <span className="text-xs text-neutral-500 font-mono">{charThemeColor}</span>
                    </div>
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button
                      type="button"
                      onClick={() => setShowCharModal(false)}
                      className="flex-1 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-700 text-neutral-900 dark:text-white font-semibold py-2.5 rounded-xl transition-all cursor-pointer text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={createCharacterMutation.isPending || updateCharacterMutation.isPending}
                      className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer text-xs shadow-lg shadow-blue-600/15"
                    >
                      {(createCharacterMutation.isPending || updateCharacterMutation.isPending) && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                      {editingCharId ? 'Save Changes' : 'Add Character'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'analytics' && (
        <div className="flex-1 overflow-y-auto p-8 bg-white dark:bg-neutral-950">
          <AnalyticsPanel />
        </div>
      )}

      {activeTab === 'watermark' && (
        <WatermarkPanel />
      )}
    </div>
  );
}
