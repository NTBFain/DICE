'use client';

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/components/AuthContext';
import { Loader2, Upload, Settings, Image as ImageIcon, Type, Sparkles } from 'lucide-react';

export default function WatermarkPanel() {
  const { apiClient } = useAuth();
  const queryClient = useQueryClient();

  const [wType, setWType] = useState<'text' | 'image'>('text');
  const [wText, setWText] = useState('WIP SOM JEED');
  const [wOpacity, setWOpacity] = useState(0.25);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreviewUrl, setLogoPreviewUrl] = useState<string>('');
  const [saving, setSaving] = useState(false);

  // Fetch current watermark settings
  const { data: settings, isLoading } = useQuery({
    queryKey: ['watermark-settings'],
    queryFn: async () => {
      const res = await apiClient.get('/commissions/watermark');
      return res.data;
    },
  });

  // Load fetched settings into state
  useEffect(() => {
    if (settings) {
      setWType(settings.type);
      setWText(settings.text);
      setWOpacity(settings.opacity);
      if (settings.image_path) {
        setLogoPreviewUrl(`http://127.0.0.1:8080${settings.image_path}`);
      }
    }
  }, [settings]);

  // Cleanup object URL
  useEffect(() => {
    return () => {
      if (logoPreviewUrl && logoPreviewUrl.startsWith('blob:')) {
        URL.revokeObjectURL(logoPreviewUrl);
      }
    };
  }, [logoPreviewUrl]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLogoFile(file);
      const url = URL.createObjectURL(file);
      setLogoPreviewUrl(url);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const formData = new FormData();
      formData.append('type', wType);
      formData.append('text', wText);
      formData.append('opacity', wOpacity.toString());
      if (logoFile) {
        formData.append('image', logoFile);
      }

      await apiClient.post('/commissions/watermark', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      queryClient.invalidateQueries({ queryKey: ['watermark-settings'] });
      alert('Watermark settings saved successfully!');
    } catch (err) {
      console.error(err);
      alert('Failed to save watermark settings');
    } finally {
      setSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  // Calculate repeat arrays for grid preview
  const previewRows = Array.from({ length: 4 });
  const previewCols = Array.from({ length: 3 });

  return (
    <div className="flex-1 overflow-y-auto p-8 bg-white dark:bg-neutral-950">
      <div className="max-w-5xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="border-b border-neutral-200 dark:border-neutral-800 pb-5">
          <h1 className="text-2xl font-extrabold tracking-tight flex items-center gap-2">
            <Settings className="w-7 h-7 text-blue-500" /> ตั้งค่าระบบลายน้ำ (Watermark Settings)
          </h1>
          <p className="text-neutral-500 dark:text-neutral-400 text-sm mt-1">
            ปรับแต่งสไตล์และความโปร่งแสงของลายน้ำที่ซ้อนทับภาพแบบร่าง (WIP) และภาพสมบูรณ์ที่ยังไม่ชำระเงินโอน
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          
          {/* Settings form */}
          <form onSubmit={handleSave} className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 p-6 rounded-3xl space-y-6 shadow-xl shadow-black/10">
            
            {/* Watermark Type Selector */}
            <div className="space-y-3">
              <label className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest block">ประเภทลายน้ำ</label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setWType('text')}
                  className={`py-3 px-4 rounded-2xl border font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    wType === 'text'
                      ? 'bg-blue-600 border-blue-500 text-white shadow-md shadow-blue-500/20'
                      : 'bg-white dark:bg-neutral-950 border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-white'
                  }`}
                >
                  <Type className="w-4 h-4" /> ใช้ข้อความ (Text)
                </button>
                <button
                  type="button"
                  onClick={() => setWType('image')}
                  className={`py-3 px-4 rounded-2xl border font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    wType === 'image'
                      ? 'bg-blue-600 border-blue-500 text-white shadow-md shadow-blue-500/20'
                      : 'bg-white dark:bg-neutral-950 border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:text-white'
                  }`}
                >
                  <ImageIcon className="w-4 h-4" /> ใช้ภาพโลโก้ (Logo)
                </button>
              </div>
            </div>

            {/* Conditionally render Text Input or Logo Upload */}
            {wType === 'text' ? (
              <div className="space-y-2">
                <label className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest block">ข้อความลายน้ำ</label>
                <input
                  type="text"
                  required
                  value={wText}
                  onChange={(e) => setWText(e.target.value)}
                  className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-3 px-4 focus:outline-none focus:border-blue-500 text-sm transition-all"
                  placeholder="ตัวอย่าง: WIP SOM JEED"
                />
              </div>
            ) : (
              <div className="space-y-3">
                <label className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest block">รูปภาพโลโก้ (PNG แนะนำรูปแบบโปร่งใส)</label>
                <div className="flex items-center justify-center w-full">
                  <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-neutral-200 dark:border-neutral-800 hover:border-blue-500/50 rounded-2xl cursor-pointer bg-white dark:bg-neutral-950 hover:bg-neutral-50 dark:hover:bg-neutral-900/40 transition-all">
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      <Upload className="w-8 h-8 text-neutral-500 mb-2" />
                      <p className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">คลิกเพื่ออัปโหลดไฟล์ภาพ</p>
                      <p className="text-[10px] text-neutral-500 mt-1">PNG, JPG (ขนาดแนะนำ 500x500 พิกเซล)</p>
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            )}

            {/* Opacity Control */}
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">
                <span>ความโปร่งแสง (Opacity)</span>
                <span className="text-blue-400 font-mono font-bold text-sm">{Math.round(wOpacity * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.05"
                max="0.80"
                step="0.05"
                value={wOpacity}
                onChange={(e) => setWOpacity(parseFloat(e.target.value))}
                className="w-full h-2 bg-neutral-200 dark:bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-blue-600 focus:outline-none"
              />
              <p className="text-[10px] text-neutral-500 italic">
                * แนะนำระดับ 20% ถึง 35% เพื่อความปลอดภัยจากการเซฟงานโดยที่งานยังคงเห็นรายละเอียดชัดเจน
              </p>
            </div>

            {/* Save Button */}
            <button
              type="submit"
              disabled={saving}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold py-3 rounded-2xl transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5 shadow-lg shadow-blue-500/10"
            >
              {saving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  กำลังบันทึก...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" /> บันทึกการตั้งค่าลายน้ำ
                </>
              )}
            </button>
          </form>

          {/* Real-time Preview Card */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest">ตัวอย่างแสดงผลสด (Interactive Preview)</h3>
            
            <div className="relative aspect-video w-full rounded-3xl overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-xl shadow-black/20 bg-neutral-100 dark:bg-neutral-900 select-none">
              
              {/* Dummy artwork background (Optimized pure CSS placeholder to prevent page load lag) */}
              <div className="w-full h-full bg-gradient-to-br from-neutral-900 via-indigo-950 to-purple-950 flex flex-col items-center justify-center relative overflow-hidden">
                {/* Decorative background grid and shapes */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
                <div className="absolute w-64 h-64 rounded-full bg-purple-500/10 blur-3xl -top-12 -left-12 animate-pulse"></div>
                <div className="absolute w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl -bottom-20 -right-20 animate-pulse"></div>
                
                {/* Mock illustration vector art */}
                <div className="relative z-10 flex flex-col items-center gap-3 text-neutral-400">
                  <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center shadow-lg backdrop-blur-sm transition-transform duration-300 hover:scale-105">
                    <ImageIcon className="w-8 h-8 text-neutral-300" />
                  </div>
                  <div className="text-center">
                    <p className="text-xs font-semibold text-neutral-300">ภาพวาดตัวอย่างสำหรับจำลองลายน้ำ</p>
                    <p className="text-[10px] text-neutral-500 mt-1">จำลองการแสดงผลบนผลงานจริงโดยไม่ต้องโหลดภาพภายนอก</p>
                  </div>
                </div>
              </div>
              
              {/* Watermark Overlay Layer */}
              <div 
                className="absolute inset-0 grid grid-cols-3 grid-rows-4 p-4 pointer-events-none overflow-hidden"
                style={{ opacity: wOpacity }}
              >
                {previewRows.map((_, rIdx) => 
                  previewCols.map((_, cIdx) => (
                    <div 
                      key={`${rIdx}-${cIdx}`} 
                      className="flex items-center justify-center rotate-[-15deg] transform scale-90"
                    >
                      {wType === 'text' ? (
                        <span className="text-[11px] md:text-sm font-bold text-white whitespace-nowrap bg-black/10 px-2 py-0.5 rounded border border-white/20 select-none drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] shadow-inner">
                          {wText || 'WIP SOM JEED'}
                        </span>
                      ) : logoPreviewUrl ? (
                        <img 
                          src={logoPreviewUrl} 
                          alt="Logo Watermark Preview" 
                          className="w-10 h-10 md:w-16 md:h-16 object-contain select-none" 
                        />
                      ) : (
                        <span className="text-[10px] md:text-xs font-bold text-white whitespace-nowrap bg-black/10 px-2 py-0.5 rounded border border-white/20">
                          (No Logo Uploaded)
                        </span>
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Status Tags */}
              <div className="absolute top-4 left-4 bg-black/60 border border-neutral-700/50 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold text-neutral-300">
                โหมดร่างแบบมีลายน้ำ (WIP Preview)
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
