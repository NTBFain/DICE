'use client';

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getAuctions, placeBid, Auction, Bid } from '@/lib/api';
import { useAuth } from '@/components/AuthContext';
import { Loader2, Gavel, RefreshCw, Calendar, Clock, AlertCircle } from 'lucide-react';
import { Link } from '@/i18n/routing';
import { useTranslations } from 'next-intl';
import Image from 'next/image';

// Countdown Timer Component
function CountdownTimer({ endTime, onEnd, t }: { endTime: string; onEnd?: () => void; t: any }) {
  const [timeLeft, setTimeLeft] = useState('');

  useEffect(() => {
    const calculateTime = () => {
      const difference = +new Date(endTime) - +new Date();
      if (difference <= 0) {
        setTimeLeft('Ended');
        if (onEnd) onEnd();
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((difference / 1000 / 60) % 60);
      const seconds = Math.floor((difference / 1000) % 60);

      const parts = [];
      if (days > 0) parts.push(`${days}d`);
      if (hours > 0 || days > 0) parts.push(`${hours}h`);
      parts.push(`${minutes}m`);
      parts.push(`${seconds}s`);
      setTimeLeft(parts.join(' '));
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [endTime, onEnd]);

  if (timeLeft === 'Ended') {
    return (
      <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-red-500/10 text-red-400 border border-red-500/20 uppercase">
        {t('ended')}
      </span>
    );
  }

  return (
    <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
      <Clock className="w-3 h-3" /> {timeLeft}
    </span>
  );
}

export default function AuctionsPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const t = useTranslations('Auctions');
  const [activeTab, setActiveTab] = useState<'active' | 'ended'>('active');
  
  // Stores bidding inputs for each auction ID: { [auctionId]: bidAmountString }
  const [bidInputs, setBidInputs] = useState<Record<number, string>>({});
  const [errorMessages, setErrorMessages] = useState<Record<number, string>>({});
  const [successMessages, setSuccessMessages] = useState<Record<number, string>>({});

  // Query to fetch auctions
  const { data: auctions = [], isLoading, refetch } = useQuery({
    queryKey: ['auctions'],
    queryFn: getAuctions,
  });

  // Mutation to place a bid
  const placeBidMutation = useMutation({
    mutationFn: ({ auctionId, amount }: { auctionId: number; amount: number }) =>
      placeBid(auctionId, amount),
    onSuccess: (updatedAuction) => {
      queryClient.invalidateQueries({ queryKey: ['auctions'] });
      setSuccessMessages((prev) => ({
        ...prev,
        [updatedAuction.id]: 'Bid placed successfully!',
      }));
      setErrorMessages((prev) => ({ ...prev, [updatedAuction.id]: '' }));
      // Clear input
      setBidInputs((prev) => ({ ...prev, [updatedAuction.id]: '' }));

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessages((prev) => ({ ...prev, [updatedAuction.id]: '' }));
      }, 3000);
    },
    onError: (error: unknown, variables) => {
      const err = error as { response?: { data?: { detail?: string } } };
      const message = err.response?.data?.detail || 'Failed to place bid. Please try again.';
      setErrorMessages((prev) => ({
        ...prev,
        [variables.auctionId]: message,
      }));
      setSuccessMessages((prev) => ({ ...prev, [variables.auctionId]: '' }));
    },
  });

  // Filter auctions
  const now = new Date();
  const filteredAuctions = auctions.filter((auction) => {
    const isEnded = auction.status === 'ENDED' || new Date(auction.end_time) < now;
    if (activeTab === 'active') {
      return auction.status === 'ACTIVE' && !isEnded;
    } else {
      return isEnded || auction.status === 'CANCELLED';
    }
  });

  const handleBidSubmit = (e: React.FormEvent, auctionId: number, minNextBid: number) => {
    e.preventDefault();
    const bidAmountStr = bidInputs[auctionId];
    if (!bidAmountStr) return;

    const bidAmount = parseFloat(bidAmountStr);
    if (isNaN(bidAmount)) {
      setErrorMessages((prev) => ({ ...prev, [auctionId]: 'Please enter a valid number.' }));
      return;
    }

    if (bidAmount < minNextBid) {
      setErrorMessages((prev) => ({
        ...prev,
        [auctionId]: `Bid must be at least ฿${minNextBid}.`,
      }));
      return;
    }

    placeBidMutation.mutate({ auctionId, amount: bidAmount });
  };

  const handleAutoBuy = (auctionId: number, autoBuyAmount: number) => {
    if (confirm(`Are you sure you want to Auto Buy this item for ฿${autoBuyAmount}? This will immediately close the auction and create your order.`)) {
      placeBidMutation.mutate({ auctionId, amount: autoBuyAmount });
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-neutral-950 text-neutral-900 dark:text-white flex flex-col">
      <div className="flex-1 p-8 max-w-6xl w-full mx-auto space-y-8">
        
        {/* Page Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-neutral-200 dark:border-neutral-800 pb-6">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight flex items-center gap-2">
              <Gavel className="text-blue-500 w-8 h-8" /> {t('title')}
            </h1>
            <p className="text-neutral-600 dark:text-neutral-400 text-sm mt-2">
              {t('subtitle')}
            </p>
          </div>
          <button
            onClick={() => refetch()}
            className="self-start md:self-center flex items-center gap-1.5 text-xs bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-200 dark:bg-neutral-800 px-4 py-2.5 rounded-xl transition-all cursor-pointer text-neutral-700 dark:text-neutral-300"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            {t('refresh')}
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex gap-4 border-b border-neutral-800/80 pb-px">
          <button
            onClick={() => setActiveTab('active')}
            className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeTab === 'active'
                ? 'border-blue-500 text-blue-400 font-extrabold'
                : 'border-transparent text-neutral-600 dark:text-neutral-400 hover:text-white'
            }`}
          >
            {t('activeAuctions')}
          </button>
          <button
            onClick={() => setActiveTab('ended')}
            className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
              activeTab === 'ended'
                ? 'border-blue-500 text-blue-400 font-extrabold'
                : 'border-transparent text-neutral-600 dark:text-neutral-400 hover:text-white'
            }`}
          >
            {t('endedAuctions')}
          </button>
        </div>

        {/* Loading / Empty States */}
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-4">
            <Loader2 className="w-10 h-10 animate-spin text-blue-500" />
            <p className="text-sm text-neutral-500 dark:text-neutral-500">{t('loading')}</p>
          </div>
        ) : filteredAuctions.length === 0 ? (
          <div className="text-center py-24 bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 rounded-3xl max-w-lg mx-auto">
            <Gavel className="w-16 h-16 text-neutral-800 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-neutral-600 dark:text-neutral-400">
              {t('emptyTitle')}
            </h3>
            <p className="text-neutral-500 dark:text-neutral-500 text-xs mt-1">
              {t('emptyDesc')}
            </p>
          </div>
        ) : (
          /* Grid of Auction Cards */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredAuctions.map((auction) => {
              const bids = auction.bids || [];
              const highestBid = bids.length > 0 ? bids[0].amount : null;
              const currentPrice = highestBid ?? auction.starting_bid;
              const minNextBid = highestBid ? highestBid + auction.bid_increment : auction.starting_bid;
              
              const isAdoptable = auction.auction_type === 'ADOPTABLE';
              
              return (
                <div
                  key={auction.id}
                  className="bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800 rounded-3xl overflow-hidden flex flex-col group relative transition-all hover:border-neutral-300 dark:border-neutral-700 shadow-xl shadow-black/35 hover:shadow-black/50"
                >
                  {/* Image/Visual header */}
                  {isAdoptable && auction.image_url ? (
                    <div className="aspect-square w-full overflow-hidden bg-white dark:bg-neutral-950 relative border-b border-neutral-850">
                      <Image
                        src={auction.image_url.startsWith('/') ? `http://127.0.0.1:8080${auction.image_url}` : auction.image_url}
                        alt={auction.title}
                        fill
                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                        className="object-cover group-hover:scale-102 transition-transform duration-500"
                      />
                    </div>
                  ) : (
                    <div className="aspect-video w-full bg-white dark:bg-neutral-950 border-b border-neutral-850 flex flex-col items-center justify-center text-neutral-600 p-4">
                      <Gavel className="w-14 h-14 mb-2 text-neutral-700" />
                      <span className="text-xs font-semibold text-neutral-500 dark:text-neutral-500 uppercase tracking-widest text-center">{t('commissionSlot')}</span>
                    </div>
                  )}

                  {/* Auction Body info */}
                  <div className="p-6 flex-1 flex flex-col justify-between space-y-6">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center flex-wrap gap-2">
                        <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full border uppercase ${
                          isAdoptable
                            ? 'bg-purple-500/10 text-purple-400 border-purple-500/20'
                            : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'
                        }`}>
                          {isAdoptable ? t('adoptable') : t('commissionSlot')}
                        </span>
                        
                        {auction.status === 'ACTIVE' && new Date(auction.end_time) > now ? (
                          <CountdownTimer endTime={auction.end_time} onEnd={refetch} t={t} />
                        ) : (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-neutral-200 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 border border-neutral-300 dark:border-neutral-700 uppercase">
                            {t('closed')}
                          </span>
                        )}
                      </div>

                      <h2 className="text-xl font-bold text-neutral-900 dark:text-white group-hover:text-blue-400 transition-colors line-clamp-1">
                        {auction.title}
                      </h2>
                      <p className="text-neutral-600 dark:text-neutral-400 text-xs line-clamp-3 whitespace-pre-line leading-relaxed">
                        {auction.description}
                      </p>
                    </div>

                    {/* Price parameters */}
                    <div className="grid grid-cols-2 gap-4 text-xs bg-neutral-950/40 p-4 rounded-2xl border border-neutral-850">
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-500 block text-[9px] uppercase tracking-wider font-bold">{t('startingBid')}</span>
                        <span className="text-neutral-900 dark:text-white font-semibold text-sm">฿{auction.starting_bid}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-500 block text-[9px] uppercase tracking-wider font-bold">{t('minIncrement')}</span>
                        <span className="text-neutral-900 dark:text-white font-semibold text-sm">฿{auction.bid_increment}</span>
                      </div>
                      <div>
                        <span className="text-neutral-500 dark:text-neutral-500 block text-[9px] uppercase tracking-wider font-bold">{t('autoBuy')}</span>
                        <span className="text-blue-400 font-extrabold text-sm">{auction.auto_buy ? `฿${auction.auto_buy}` : t('none')}</span>
                      </div>
                      <div>
                        <span className="text-neutral-600 dark:text-neutral-400 block text-[9px] uppercase tracking-wider font-bold">{t('currentPrice')}</span>
                        <span className="text-emerald-400 font-extrabold text-sm">฿{currentPrice}</span>
                      </div>
                    </div>

                    {/* Winner and end results */}
                    {auction.winner_id && (
                      <div className="bg-emerald-500/5 border border-emerald-500/10 p-3 rounded-2xl text-xs text-emerald-400 flex flex-col gap-1">
                        <div className="flex justify-between">
                          <span>{t('winner')} <strong className="text-neutral-900 dark:text-white">{auction.winner_name || t('unknown')} (ID: {auction.winner_id})</strong></span>
                          <span>{t('winningBid')} <strong>฿{auction.winning_bid}</strong></span>
                        </div>
                        <span className="text-[10px] text-neutral-600 dark:text-neutral-400 italic">{t('winnerNote')}</span>
                      </div>
                    )}

                    {/* Date details */}
                    <div className="text-[10px] text-neutral-500 dark:text-neutral-500 flex items-center justify-between">
                      <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {t('closes')} {new Date(auction.end_time).toLocaleDateString()}</span>
                      <span>{t('totalBids')} {bids.length}</span>
                    </div>

                    {/* Bids list */}
                    <div className="space-y-2 border-t border-neutral-850 pt-4">
                      <span className="text-[10px] font-bold text-neutral-600 dark:text-neutral-400 uppercase tracking-widest block">{t('bidHistory')}</span>
                      {bids.length === 0 ? (
                        <p className="text-[10px] text-neutral-600 italic">{t('noBids')}</p>
                      ) : (
                        <div className="max-h-32 overflow-y-auto space-y-1.5 pr-1 scrollbar-thin">
                          {bids.map((bid) => (
                            <div key={bid.id} className="flex justify-between items-center text-[10px] bg-neutral-950/60 py-1.5 px-3 rounded-xl border border-neutral-850">
                              <div className="flex flex-col">
                                <span className="text-neutral-700 dark:text-neutral-300 font-medium truncate max-w-[120px]">{bid.bidder_name}</span>
                                <span className="text-neutral-500 dark:text-neutral-500 text-[8px]">{new Date(bid.created_at).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'medium' })}</span>
                              </div>
                              <span className="text-emerald-400 font-bold">฿{bid.amount}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Action buttons (Bidding panel) */}
                    {auction.status === 'ACTIVE' && new Date(auction.end_time) > now ? (
                      user ? (
                        <div className="border-t border-neutral-850 pt-4 space-y-3">
                          <form
                            onSubmit={(e) => handleBidSubmit(e, auction.id, minNextBid)}
                            className="flex gap-2"
                          >
                            <div className="relative flex-1">
                              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-neutral-500 dark:text-neutral-500 text-xs">
                                ฿
                              </span>
                              <input
                                type="number"
                                required
                                min={minNextBid}
                                step="any"
                                placeholder={`Min ฿${minNextBid}`}
                                value={bidInputs[auction.id] || ''}
                                onChange={(e) =>
                                  setBidInputs((prev) => ({ ...prev, [auction.id]: e.target.value }))
                                }
                                className="w-full bg-white dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 text-neutral-900 dark:text-white rounded-xl py-2 pl-7 pr-3 placeholder-neutral-600 focus:outline-none focus:border-blue-500 text-xs"
                              />
                            </div>
                            <button
                              type="submit"
                              disabled={placeBidMutation.isPending}
                              className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded-xl text-xs transition-all cursor-pointer disabled:opacity-50"
                            >
                              {t('placeBid')}
                            </button>
                          </form>
                          
                          {auction.auto_buy && (
                            <button
                              type="button"
                              onClick={() => handleAutoBuy(auction.id, auction.auto_buy!)}
                              disabled={placeBidMutation.isPending}
                              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-neutral-900 dark:text-white font-extrabold py-2 rounded-xl text-xs transition-all cursor-pointer shadow-md shadow-blue-500/10 flex items-center justify-center gap-1"
                            >
                              {t('autoBuyFor', { amount: auction.auto_buy })}
                            </button>
                          )}

                          {errorMessages[auction.id] && (
                            <div className="text-red-400 text-[10px] flex items-center gap-1 bg-red-950/20 border border-red-900/30 p-2 rounded-lg">
                              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                              <span>{errorMessages[auction.id]}</span>
                            </div>
                          )}

                          {successMessages[auction.id] && (
                            <div className="text-emerald-400 text-[10px] bg-emerald-950/20 border border-emerald-900/30 p-2 rounded-lg text-center">
                              {successMessages[auction.id]}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="border-t border-neutral-850 pt-4 text-center">
                          <Link
                            href="/login"
                            className="inline-block bg-neutral-50 dark:bg-neutral-900 hover:bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:text-neutral-900 dark:text-white border border-neutral-200 dark:border-neutral-800 font-bold px-4 py-2.5 rounded-xl text-xs transition-all w-full"
                          >
                            {t('loginToBid')}
                          </Link>
                        </div>
                      )
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
