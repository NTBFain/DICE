'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { getPortfolio, getCharacters } from '@/lib/api';
import { Loader2, Image as ImageIcon, Lock, Filter } from 'lucide-react';
import { useTranslations } from 'next-intl';

const WORK_TYPES = [
  { id: 'ILLUSTRATION', label: 'Illustration' },
  { id: 'SKETCH', label: 'Sketch & Doodle' },
  { id: 'COMIC', label: 'Comic' },
  { id: 'LIVE2D', label: 'Live2D' },
  { id: 'CONCEPT_ART', label: 'Concept Art' }
];

export default function PortfolioPage() {
  const t = useTranslations('Portfolio');
  const searchParams = useSearchParams();
  const [selectedCharacter, setSelectedCharacter] = useState<number | 'all'>('all');
  const [selectedWorkType, setSelectedWorkType] = useState<string | 'all'>('all');

  useEffect(() => {
    const characterIdParam = searchParams.get('character');
    if (characterIdParam) {
      const parsedId = parseInt(characterIdParam, 10);
      if (!isNaN(parsedId)) {
        setSelectedCharacter(parsedId);
      }
    }
  }, [searchParams]);

  const { data: artworks, isLoading: isLoadingArtworks, isError: isErrorArtworks } = useQuery({
    queryKey: ['portfolio'],
    queryFn: getPortfolio,
  });

  const { data: characters, isLoading: isLoadingCharacters } = useQuery({
    queryKey: ['characters'],
    queryFn: getCharacters,
  });

  const filteredArtworks = artworks?.filter(artwork => {
    const matchCharacter = selectedCharacter === 'all' || artwork.character_id === selectedCharacter;
    const matchWorkType = selectedWorkType === 'all' || artwork.work_type === selectedWorkType;
    return matchCharacter && matchWorkType;
  }) || [];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-8 text-center max-w-2xl mx-auto">
        <h1 className="text-4xl font-bold tracking-tight mb-4">{t('title')}</h1>
        <p className="text-neutral-600 dark:text-neutral-400 text-lg">
          {t('subtitle')}
        </p>
      </div>

      {/* Dual Navigation Filters */}
      <div className="mb-12 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-4 text-neutral-800 dark:text-neutral-200 font-bold text-lg">
          <Filter className="w-5 h-5" /> Filters
        </div>
        
        {/* Character Axis */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-neutral-500 uppercase tracking-wider mb-3">Characters</h3>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedCharacter('all')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${selectedCharacter === 'all' ? 'bg-blue-600 text-white shadow-md' : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700'}`}
            >
              All
            </button>
            {!isLoadingCharacters && characters?.map(char => (
              <button
                key={char.id}
                onClick={() => setSelectedCharacter(char.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${selectedCharacter === char.id ? 'bg-blue-600 text-white shadow-md' : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700'}`}
              >
                {char.name}
              </button>
            ))}
          </div>
        </div>

        {/* Work Type Axis */}
        <div>
          <h3 className="text-sm font-semibold text-neutral-500 uppercase tracking-wider mb-3">Work Type</h3>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedWorkType('all')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${selectedWorkType === 'all' ? 'bg-purple-600 text-white shadow-md' : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700'}`}
            >
              All
            </button>
            {WORK_TYPES.map(wt => (
              <button
                key={wt.id}
                onClick={() => setSelectedWorkType(wt.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${selectedWorkType === wt.id ? 'bg-purple-600 text-white shadow-md' : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700'}`}
              >
                {wt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {isLoadingArtworks && (
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="w-12 h-12 text-blue-500 animate-spin mb-4" />
          <p className="text-neutral-500 dark:text-neutral-500 font-medium">{t('loading')}</p>
        </div>
      )}

      {isErrorArtworks && (
        <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-6 rounded-2xl text-center max-w-lg mx-auto">
          {t('error')}
        </div>
      )}

      {!isLoadingArtworks && !isErrorArtworks && filteredArtworks.length === 0 && (
        <div className="text-center py-20 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl transition-opacity duration-300">
          <ImageIcon className="w-16 h-16 text-neutral-700 mx-auto mb-4 opacity-50" />
          <h3 className="text-xl font-bold text-neutral-700 dark:text-neutral-300">No artworks found</h3>
          <p className="text-neutral-500 dark:text-neutral-500 mt-2">Try adjusting your filters to see more results.</p>
        </div>
      )}

      {!isLoadingArtworks && filteredArtworks.length > 0 && (
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6 transition-all duration-500">
          {filteredArtworks.map((artwork) => (
            <div 
              key={artwork.id} 
              className="break-inside-avoid relative group rounded-2xl overflow-hidden bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 animate-in fade-in zoom-in duration-500"
            >
              <img 
                src={artwork.image_url.startsWith('/') ? `http://127.0.0.1:8080${artwork.image_url}` : artwork.image_url}
                alt={artwork.title}
                className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-1">{artwork.title}</h3>
                    {artwork.character && (
                       <span className="inline-block text-xs font-semibold px-2 py-1 bg-white/20 text-white rounded-md mb-2 backdrop-blur-md">
                         {artwork.character.name}
                       </span>
                    )}
                  </div>
                  {artwork.visibility_status !== 'PUBLIC' && (
                    <span className="inline-flex items-center gap-1 text-xs font-bold px-2 py-1 bg-neutral-800/80 rounded-md text-neutral-300 backdrop-blur-md border border-neutral-700">
                      <Lock className="w-3 h-3" /> {artwork.visibility_status}
                    </span>
                  )}
                </div>
                {artwork.description && (
                  <p className="text-sm text-neutral-300 line-clamp-2 mt-1">{artwork.description}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
