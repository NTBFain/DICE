'use client';

import { useQuery } from '@tanstack/react-query';
import { getCharacters } from '@/lib/api';
import { Loader2, Users, Palette, ArrowRight } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { Link } from '@/i18n/routing';

export default function CharactersPage() {
  const t = useTranslations('Portfolio'); // Reuse Portfolio translations or add Character ones
  
  const { data: characters, isLoading, isError } = useQuery({
    queryKey: ['characters'],
    queryFn: getCharacters,
  });

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-12 text-center max-w-2xl mx-auto">
        <h1 className="text-4xl font-bold tracking-tight mb-4 flex items-center justify-center gap-3">
          <Users className="w-10 h-10 text-blue-500" />
          Characters Universe
        </h1>
        <p className="text-neutral-600 dark:text-neutral-400 text-lg">
          Explore artworks sorted by your favorite characters. Select a profile below to view their specific gallery.
        </p>
      </div>

      {isLoading && (
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="w-12 h-12 text-blue-500 animate-spin mb-4" />
          <p className="text-neutral-500 dark:text-neutral-500 font-medium">{t('loading')}</p>
        </div>
      )}

      {isError && (
        <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-6 rounded-2xl text-center max-w-lg mx-auto">
          Failed to load characters.
        </div>
      )}

      {!isLoading && !isError && characters?.length === 0 && (
        <div className="text-center py-20 bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl">
          <Users className="w-16 h-16 text-neutral-700 mx-auto mb-4 opacity-50" />
          <h3 className="text-xl font-bold text-neutral-700 dark:text-neutral-300">No Characters Found</h3>
          <p className="text-neutral-500 dark:text-neutral-500 mt-2">There are currently no characters added to the database.</p>
        </div>
      )}

      {!isLoading && characters && characters.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {characters.map((char) => (
            <Link 
              key={char.id}
              href={`/portfolio?character=${char.id}`}
              className="group block bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl overflow-hidden hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-300 transform hover:-translate-y-1 relative"
            >
              {char.image_url ? (
                <div className="h-64 w-full relative overflow-hidden bg-neutral-100 dark:bg-neutral-900">
                  <img
                    src={char.image_url.startsWith('/') ? `http://127.0.0.1:8080${char.image_url}` : char.image_url}
                    alt={char.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent"></div>
                  <Palette className="absolute top-4 right-4 text-white/70 w-6 h-6 drop-shadow-md" />
                  
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3 className="text-2xl font-bold text-white mb-1 group-hover:text-blue-400 transition-colors drop-shadow-md">
                      {char.name}
                    </h3>
                    <p className="text-white/80 text-sm line-clamp-2 mb-3 drop-shadow-md">
                      {char.description || "A mysterious character in the universe."}
                    </p>
                    <div className="flex items-center text-xs font-bold text-blue-400 group-hover:text-blue-300 uppercase tracking-widest drop-shadow-md">
                      View Gallery <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  <div 
                    className="h-32 w-full relative"
                    style={{ backgroundColor: char.theme_color || '#3b82f6' }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-b from-black/0 to-black/40"></div>
                    <Palette className="absolute top-4 right-4 text-white/50 w-6 h-6" />
                  </div>
                  <div className="p-6 relative">
                    <div 
                      className="w-16 h-16 rounded-2xl absolute -top-8 bg-neutral-800 border-4 border-white dark:border-neutral-900 flex items-center justify-center shadow-lg"
                      style={{ backgroundColor: char.theme_color || '#1e3a8a' }}
                    >
                      <span className="text-white font-bold text-2xl">
                        {char.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="mt-8">
                      <h3 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2 group-hover:text-blue-500 transition-colors">
                        {char.name}
                      </h3>
                      <p className="text-neutral-500 dark:text-neutral-400 text-sm line-clamp-3 mb-4">
                        {char.description || "A mysterious character in the universe."}
                      </p>
                      <div className="flex items-center text-sm font-semibold text-blue-500 group-hover:text-blue-400">
                        View Gallery <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </div>
                </>
              )}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
