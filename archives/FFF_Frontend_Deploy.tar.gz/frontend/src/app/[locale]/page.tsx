'use client';

import { Link } from '@/i18n/routing';
import { useAuth } from '@/components/AuthContext';
import { PenTool, LayoutTemplate, Briefcase, FileCheck, ArrowRight, ShieldCheck } from 'lucide-react';
import { useTranslations } from 'next-intl';

export default function Home() {
  const { user } = useAuth();
  const t = useTranslations('Home');

  return (
    <div className="flex-1 flex flex-col justify-center items-center py-20 px-4 relative overflow-hidden bg-white dark:bg-neutral-950">
      {/* Radiant ambient glow */}
      <div className="absolute top-[-10%] left-[-20%] w-[80%] h-[60%] bg-blue-600/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-20%] w-[80%] h-[60%] bg-purple-600/5 rounded-full blur-[120px] pointer-events-none" />

      {/* Hero section */}
      <div className="max-w-4xl w-full text-center space-y-8 relative z-10 my-auto">
        <div className="inline-flex items-center gap-1.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wider">
          <PenTool className="w-3.5 h-3.5" /> {t('badge')}
        </div>

        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-neutral-900 dark:text-white leading-tight">
          {t('title1')} <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">{t('titleHighlight')}</span>{t('title2')}
        </h1>

        <p className="text-neutral-600 dark:text-neutral-400 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
          {t('description')}
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
          <Link
            href="/portfolio"
            className="flex h-12 items-center justify-center gap-2 rounded-2xl bg-white text-neutral-950 font-bold px-6 hover:bg-neutral-200 transition-all shadow-lg shadow-white/5"
          >
            <LayoutTemplate className="w-4 h-4" /> {t('browsePortfolio')}
          </Link>
          <Link
            href={user ? (user.is_admin ? '/dashboard/admin' : '/dashboard/client') : '/login'}
            className="flex h-12 items-center justify-center gap-2 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/50 hover:bg-neutral-50 dark:bg-neutral-900 text-neutral-900 dark:text-white font-bold px-6 hover:border-neutral-300 dark:border-neutral-700 transition-all"
          >
            <Briefcase className="w-4 h-4" />
            {user ? t('goToDashboard') : t('hireMe')}
            <ArrowRight className="w-4 h-4 text-neutral-500 dark:text-neutral-500" />
          </Link>
        </div>
      </div>

      {/* Features Grid / Commission Workflow */}
      <div className="max-w-5xl w-full mt-24 relative z-10 border-t border-neutral-200 dark:border-neutral-900 pt-16">
        <div className="text-center mb-12">
          <h2 className="text-2xl font-bold text-neutral-900 dark:text-white mb-2">{t('secureWorkflow')}</h2>
          <p className="text-neutral-500 dark:text-neutral-500 text-xs uppercase tracking-widest font-semibold">{t('howItWorks')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-neutral-50 dark:bg-neutral-900/30 border border-neutral-200 dark:border-neutral-900 p-6 rounded-3xl space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center font-bold">
              1
            </div>
            <h3 className="font-bold text-neutral-900 dark:text-white text-sm">{t('step1Title')}</h3>
            <p className="text-neutral-600 dark:text-neutral-400 text-xs leading-relaxed">
              {t('step1Desc')}
            </p>
          </div>

          <div className="bg-neutral-50 dark:bg-neutral-900/30 border border-neutral-200 dark:border-neutral-900 p-6 rounded-3xl space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
              2
            </div>
            <h3 className="font-bold text-neutral-900 dark:text-white text-sm">{t('step2Title')}</h3>
            <p className="text-neutral-600 dark:text-neutral-400 text-xs leading-relaxed">
              {t('step2Desc')}
            </p>
          </div>

          <div className="bg-neutral-50 dark:bg-neutral-900/30 border border-neutral-200 dark:border-neutral-900 p-6 rounded-3xl space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              3
            </div>
            <h3 className="font-bold text-neutral-900 dark:text-white text-sm">{t('step3Title')}</h3>
            <p className="text-neutral-600 dark:text-neutral-400 text-xs leading-relaxed">
              {t('step3Desc')}
            </p>
          </div>
        </div>

        <div className="mt-12 text-center text-xs text-neutral-500 dark:text-neutral-500 flex items-center justify-center gap-1.5 bg-neutral-100 dark:bg-neutral-900/10 border border-neutral-200 dark:border-neutral-900 w-fit mx-auto px-4 py-2 rounded-2xl">
          <ShieldCheck className="w-4 h-4 text-emerald-400" /> {t('escrowNote')}
        </div>
      </div>
    </div>
  );
}
