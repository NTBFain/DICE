'use client';

import { Link, useRouter, usePathname } from '@/i18n/routing';
import { useAuth } from './AuthContext';
import { LayoutTemplate, PenTool, UserCircle, LogOut, LayoutDashboard, Gavel, Globe, Users } from 'lucide-react';
import { useTranslations, useLocale } from 'next-intl';
import NotificationBell from './NotificationBell';

export default function Header() {
  const { user, logoutUser } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const locale = useLocale();
  const t = useTranslations('Navigation');

  const handleLogout = () => {
    logoutUser();
    router.push('/');
  };

  const switchLanguage = () => {
    const nextLocale = locale === 'en' ? 'th' : 'en';
    router.replace(pathname, { locale: nextLocale });
  };

  return (
    <header className="border-b border-neutral-800 bg-neutral-900/50 backdrop-blur-md sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="font-bold text-xl tracking-tight text-white flex items-center gap-2">
          <PenTool className="text-blue-500 w-5 h-5" />
          Som<span className="text-blue-500">Jeed</span>
        </Link>
        <nav className="flex gap-6 items-center">
          <Link
            href="/portfolio"
            className="text-sm font-medium text-neutral-300 hover:text-white transition-colors flex items-center gap-1"
          >
            <LayoutTemplate className="w-4 h-4" /> {t('portfolio')}
          </Link>

          <Link
            href="/characters"
            className="text-sm font-medium text-neutral-300 hover:text-white transition-colors flex items-center gap-1"
          >
            <Users className="w-4 h-4" /> {t('characters')}
          </Link>

          <Link
            href="/auctions"
            className="text-sm font-medium text-neutral-300 hover:text-white transition-colors flex items-center gap-1"
          >
            <Gavel className="w-4 h-4" /> {t('auctions')}
          </Link>
          
          {user && (
            <Link
              href={user.is_admin ? '/dashboard/admin' : '/dashboard/client'}
              className="text-sm font-medium text-neutral-300 hover:text-white transition-colors flex items-center gap-1"
            >
              <LayoutDashboard className="w-4 h-4" /> {user.is_admin ? t('adminPanel') : t('myOrders')}
            </Link>
          )}

          <div className="w-px h-4 bg-neutral-800"></div>

          {/* Language Switcher */}
          <button
            onClick={switchLanguage}
            className="text-sm font-medium text-neutral-300 hover:text-white transition-colors flex items-center gap-1 uppercase bg-neutral-800/50 px-2 py-1 rounded-md"
          >
            <Globe className="w-4 h-4" /> {locale}
          </button>

          {user ? (
            <div className="flex items-center gap-4">
              <span className="text-sm text-neutral-400 font-medium">
                {t('hi')} <span className="text-white font-bold">{user.full_name}</span>
                {user.is_admin && <span className="ml-1.5 text-xs bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded-full border border-blue-500/30">{t('artist')}</span>}
              </span>
              <NotificationBell />
              <button
                onClick={handleLogout}
                className="text-sm font-medium text-red-400 hover:text-red-300 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <LogOut className="w-4 h-4" /> {t('logout')}
              </button>
            </div>
          ) : (
            <Link
              href="/login"
              className="text-sm font-medium text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-1"
            >
              <UserCircle className="w-4 h-4" /> {t('login')}
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
